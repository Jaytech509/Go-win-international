import 'package:flutter/material.dart';
import 'package:ascendant_reach/services/translation_service.dart';
import 'package:ascendant_reach/services/storage_service.dart';
import 'package:ascendant_reach/screens/auth_screen.dart';
import 'package:ascendant_reach/screens/comprehensive_profile_screen.dart';
import 'package:ascendant_reach/screens/enhanced_profile_screen.dart';

class CommonAppBar extends StatelessWidget implements PreferredSizeWidget {
  final String title;
  final bool showActions;

  const CommonAppBar({
    super.key,
    required this.title,
    this.showActions = true,
  });

  @override
  Size get preferredSize => const Size.fromHeight(kToolbarHeight);

  @override
  Widget build(BuildContext context) {
    return AppBar(
      title: Text(TranslationService.translate(title)),
      backgroundColor: Theme.of(context).primaryColor,
      foregroundColor: Colors.white,
      elevation: 2,
      actions: showActions ? [
        // Language Selector
        PopupMenuButton<AppLanguage>(
          icon: const Icon(Icons.language),
          tooltip: TranslationService.translate('language'),
          onSelected: (language) {
            TranslationService.setLanguage(language);
            // Force rebuild of the entire app
            if (context.mounted) {
              Navigator.of(context).pushAndRemoveUntil(
                MaterialPageRoute(builder: (_) => const AuthScreen()),
                (route) => false,
              );
            }
          },
          itemBuilder: (context) => TranslationService.getLanguageOptions()
              .map((item) => PopupMenuItem<AppLanguage>(
                    value: item.value,
                    child: item.child,
                  ))
              .toList(),
        ),
        
        // Download App Button
        IconButton(
          icon: const Icon(Icons.download),
          tooltip: TranslationService.translate('download_app'),
          onPressed: () => _showDownloadDialog(context),
        ),
        
        // Account Actions Menu
        PopupMenuButton<String>(
          icon: const Icon(Icons.account_circle),
          onSelected: (value) async {
            if (value == 'profile_comprehensive') {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const ComprehensiveProfileScreen()),
              );
            } else if (value == 'profile_enhanced') {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const EnhancedProfileScreen()),
              );
            } else if (value == 'logout') {
              await _logout(context);
            } else if (value == 'switch_account') {
              await _switchAccount(context);
            }
          },
          itemBuilder: (context) => [
            PopupMenuItem(
              value: 'profile_comprehensive',
              child: ListTile(
                leading: const Icon(Icons.person_outline, color: Colors.blue),
                title: Text(TranslationService.translate('comprehensive_profile')),
                subtitle: Text(TranslationService.translate('view_all_profile_details'), 
                  style: const TextStyle(fontSize: 11)),
                contentPadding: EdgeInsets.zero,
              ),
            ),
            PopupMenuItem(
              value: 'profile_enhanced',
              child: ListTile(
                leading: const Icon(Icons.edit, color: Colors.green),
                title: Text(TranslationService.translate('edit_profile')),
                subtitle: Text(TranslationService.translate('update_personal_information'), 
                  style: const TextStyle(fontSize: 11)),
                contentPadding: EdgeInsets.zero,
              ),
            ),
            const PopupMenuDivider(),
            PopupMenuItem(
              value: 'switch_account',
              child: ListTile(
                leading: const Icon(Icons.swap_horiz, color: Colors.orange),
                title: Text(TranslationService.translate('switch_account')),
                subtitle: Text(TranslationService.translate('change_to_different_account'), 
                  style: const TextStyle(fontSize: 11)),
                contentPadding: EdgeInsets.zero,
              ),
            ),
            PopupMenuItem(
              value: 'logout',
              child: ListTile(
                leading: const Icon(Icons.logout, color: Colors.red),
                title: Text(TranslationService.translate('logout')),
                subtitle: Text(TranslationService.translate('sign_out_of_account'), 
                  style: const TextStyle(fontSize: 11)),
                contentPadding: EdgeInsets.zero,
              ),
            ),
          ],
        ),
      ] : null,
    );
  }

  void _showDownloadDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Row(
          children: [
            const Icon(Icons.download, color: Colors.blue),
            const SizedBox(width: 8),
            Text(TranslationService.translate('download_app')),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Download GO-WIN INTERNATIONAL mobile app:',
              style: Theme.of(context).textTheme.bodyLarge,
            ),
            const SizedBox(height: 16),
            _buildDownloadButton(
              context,
              'Android APK',
              Icons.android,
              Colors.green,
              'https://gowin-international.com/download/android',
            ),
            const SizedBox(height: 8),
            _buildDownloadButton(
              context,
              'iOS App Store',
              Icons.phone_iphone,
              Colors.blue,
              'https://apps.apple.com/gowin-international',
            ),
            const SizedBox(height: 8),
            _buildDownloadButton(
              context,
              'Web Version',
              Icons.web,
              Colors.orange,
              'https://app.gowin-international.com',
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(TranslationService.translate('close')),
          ),
        ],
      ),
    );
  }

  Widget _buildDownloadButton(
    BuildContext context,
    String title,
    IconData icon,
    Color color,
    String url,
  ) {
    return InkWell(
      onTap: () {
        // In a real app, you would use url_launcher to open the URL
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Opening: $url'),
            duration: const Duration(seconds: 2),
          ),
        );
      },
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          border: Border.all(color: color.withValues(alpha: 0.3)),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Row(
          children: [
            Icon(icon, color: color),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                title,
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
            Icon(Icons.launch, color: Colors.grey[600], size: 18),
          ],
        ),
      ),
    );
  }

  Future<void> _logout(BuildContext context) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Row(
          children: [
            const Icon(Icons.logout, color: Colors.orange),
            const SizedBox(width: 8),
            Text(TranslationService.translate('logout')),
          ],
        ),
        content: Text(
          'Are you sure you want to logout?',
          style: Theme.of(context).textTheme.bodyLarge,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: Text(TranslationService.translate('cancel')),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.orange,
              foregroundColor: Colors.white,
            ),
            child: Text(TranslationService.translate('logout')),
          ),
        ],
      ),
    );

    if (confirmed == true && context.mounted) {
      // Clear current member session
      await StorageService.clearCurrentMember();
      
      // Navigate to auth screen
      Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(builder: (_) => const AuthScreen()),
        (route) => false,
      );

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Logged out successfully'),
          backgroundColor: Colors.green,
        ),
      );
    }
  }

  Future<void> _switchAccount(BuildContext context) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Row(
          children: [
            const Icon(Icons.swap_horiz, color: Colors.blue),
            const SizedBox(width: 8),
            Text(TranslationService.translate('switch_account')),
          ],
        ),
        content: Text(
          'Switch to a different account? This will log you out of the current account.',
          style: Theme.of(context).textTheme.bodyLarge,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: Text(TranslationService.translate('cancel')),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.blue,
              foregroundColor: Colors.white,
            ),
            child: Text(TranslationService.translate('switch_account')),
          ),
        ],
      ),
    );

    if (confirmed == true && context.mounted) {
      // Clear current member session
      await StorageService.clearCurrentMember();
      
      // Navigate to auth screen
      Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(builder: (_) => const AuthScreen()),
        (route) => false,
      );

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Account switched. Please sign in with your new account.'),
          backgroundColor: Colors.blue,
        ),
      );
    }
  }
}