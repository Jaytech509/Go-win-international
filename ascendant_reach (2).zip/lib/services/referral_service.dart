import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:share_plus/share_plus.dart';
import 'package:ascendant_reach/models/member.dart';
import 'package:ascendant_reach/services/storage_service.dart';

class ReferralService {
  static const String _baseWebUrl = 'https://go-win-international.web.app';
  static const String _appStoreUrl = 'https://apps.apple.com/app/go-win-international';
  static const String _playStoreUrl = 'https://play.google.com/store/apps/details?id=com.gowin.international';

  /// Generate a web-based referral link for sharing
  static String generateWebReferralLink(String referralCode) {
    return '$_baseWebUrl/register?ref=$referralCode';
  }

  /// Generate app store links with referral code
  static String generateAppStoreReferralLink(String referralCode) {
    return '$_appStoreUrl?ref=$referralCode';
  }

  static String generatePlayStoreReferralLink(String referralCode) {
    return '$_playStoreUrl&ref=$referralCode';
  }

  /// Create a complete referral message with all links
  static String createReferralMessage(Member member) {
    final webLink = generateWebReferralLink(member.referralCode);
    
    return '''
🏆 JOIN GO-WIN INTERNATIONAL WINNERS CIRCLE! 🏆

Hi! I'm inviting you to join GO-WIN INTERNATIONAL, an exclusive multi-level marketing platform where you can earn real money through our unique 14-member pyramidal board system.

💰 WHAT YOU GET:
• 100% commission from direct referrals
• 75% from 2nd level referrals  
• 50% from 3rd level referrals
• Automatic rank promotions
• Multiple earning opportunities

👑 MY REFERRAL CODE: ${member.referralCode}

🌐 JOIN VIA WEB: $webLink

📱 Or download the app:
• iOS: ${generateAppStoreReferralLink(member.referralCode)}
• Android: ${generatePlayStoreReferralLink(member.referralCode)}

Start your journey to financial freedom today!

#GoWinInternational #MLM #EarnMoney #ReferralProgram
    ''';
  }

  /// Share referral link via system share
  static Future<void> shareReferralLink(Member member) async {
    final message = createReferralMessage(member);
    await Share.share(
      message,
      subject: 'Join GO-WIN INTERNATIONAL Winners Circle!',
    );
  }

  /// Open referral link in browser
  static Future<void> openReferralLink(String referralCode) async {
    final url = generateWebReferralLink(referralCode);
    final uri = Uri.parse(url);
    
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } else {
      throw 'Could not launch $url';
    }
  }

  /// Handle incoming referral from web or deep link
  static Future<String?> handleIncomingReferral(String? referralCode) async {
    if (referralCode == null || referralCode.isEmpty) return null;

    // Validate referral code exists
    final members = StorageService.getMembers();
    final referrer = members.cast<Member?>().firstWhere(
      (m) => m?.referralCode == referralCode,
      orElse: () => null,
    );

    return referrer?.referralCode;
  }

  /// Create QR code data for referral
  static String generateQRCodeData(String referralCode) {
    return generateWebReferralLink(referralCode);
  }

  /// Get social media sharing templates
  static Map<String, String> getSocialMediaTemplates(Member member) {
    final webLink = generateWebReferralLink(member.referralCode);
    
    return {
      'whatsapp': '''
🏆 JOIN THE WINNERS CIRCLE! 🏆

Earn money with GO-WIN INTERNATIONAL!
💰 100% from direct referrals
👑 Automatic rank promotions
🌟 Multiple income streams

My referral code: ${member.referralCode}
Join here: $webLink

#GoWinInternational #MLM
      ''',
      
      'telegram': '''
🏆 GO-WIN INTERNATIONAL INVITATION 🏆

Join me in this exclusive MLM platform!
• Earn real money through referrals
• 14-member pyramidal board system
• Multiple earning levels

Code: ${member.referralCode}
Link: $webLink
      ''',
      
      'instagram': '''
🏆 WINNERS CIRCLE INVITATION 🏆

Ready to earn real money? Join GO-WIN INTERNATIONAL!

Use my code: ${member.referralCode}
Link in bio: $webLink

#GoWinInternational #MLM #EarnMoney #WinnersCircle
      ''',
      
      'facebook': '''
🏆 Exciting Opportunity Alert! 🏆

I'm part of GO-WIN INTERNATIONAL, an amazing MLM platform where you can earn through referrals and board completions!

What's in it for you:
💰 100% commission from direct referrals
📈 Progressive earning levels
👑 Automatic rank promotions
🎯 Clear path to financial growth

Ready to join the Winners Circle?
Use my referral code: ${member.referralCode}
Register here: $webLink

#GoWinInternational #MLM #EarnMoney #FinancialFreedom
      '''
    };
  }

  /// Launch social media sharing
  static Future<void> shareOnPlatform(Member member, String platform) async {
    final templates = getSocialMediaTemplates(member);
    final message = templates[platform] ?? createReferralMessage(member);
    
    String platformUrl;
    switch (platform) {
      case 'whatsapp':
        platformUrl = 'whatsapp://send?text=${Uri.encodeComponent(message)}';
        break;
      case 'telegram':
        platformUrl = 'tg://msg?text=${Uri.encodeComponent(message)}';
        break;
      case 'instagram':
        platformUrl = 'instagram://story-camera';
        break;
      case 'facebook':
        platformUrl = 'fb://facewebmodal/f?href=${Uri.encodeComponent("https://www.facebook.com/sharer/sharer.php?u=${generateWebReferralLink(member.referralCode)}&quote=${Uri.encodeComponent(message)}")}';
        break;
      default:
        await Share.share(message);
        return;
    }

    final uri = Uri.parse(platformUrl);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri);
    } else {
      // Fallback to regular sharing
      await Share.share(message);
    }
  }
}