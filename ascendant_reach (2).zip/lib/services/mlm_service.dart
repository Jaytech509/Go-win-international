import 'package:uuid/uuid.dart';
import 'package:ascendant_reach/models/member.dart';
import 'package:ascendant_reach/models/board.dart';
import 'package:ascendant_reach/models/transaction.dart';
import 'package:ascendant_reach/models/board_join_request.dart';
import 'package:ascendant_reach/models/withdrawal_request.dart';
import 'package:ascendant_reach/models/notification.dart';
import 'package:ascendant_reach/services/storage_service.dart';
import 'package:ascendant_reach/services/notification_service.dart';

class MLMService {
  static const _uuid = Uuid();
  
  // Administrator emails with full privileges
  static const List<String> _adminEmails = [
    'jaytechpromo@gmail.com',
    'lubejy09@gmail.com',
    'luberissejames60@gmail.com',
    'jamesluberisse30@gmail.com',
  ];
  
  static bool isAdministrator(String email) {
    return _adminEmails.contains(email.toLowerCase());
  }

  static String generateReferralCode() {
    return _uuid.v4().substring(0, 8).toUpperCase();
  }

  static Future<void> _ensureDefaultMembers() async {
    try {
      final now = DateTime.now();
      final defaultMembers = [
        Member(
          id: 'admin-jaytechpromo',
          name: 'Jay Tech Admin',
          email: 'jaytechpromo@gmail.com',
          phoneNumber: '+1-555-0100',
          referralCode: 'JAYADMIN',
          rank: MemberRank.legend,
          level: 7,
          boardPosition: -1,
          directReferrals: [],
          points: 1000,
          walletBalance: 10000.0,
          earningWallet: 5000.0,
          joinDate: now.subtract(const Duration(days: 400)),
          isActive: true,
          isAdmin: true,
          stars: 7,
        ),
        Member(
          id: 'admin-lubejy09',
          name: 'Lube Admin',
          email: 'lubejy09@gmail.com',
          phoneNumber: '+1-555-0101',
          referralCode: 'LUBEADMIN',
          rank: MemberRank.legend,
          level: 7,
          boardPosition: -1,
          directReferrals: [],
          points: 1000,
          walletBalance: 10000.0,
          earningWallet: 5000.0,
          joinDate: now.subtract(const Duration(days: 400)),
          isActive: true,
          isAdmin: true,
          stars: 7,
        ),
        Member(
          id: 'demo-leader-1',
          name: 'John Legend',
          email: 'john.legend@gowin.com',
          phoneNumber: '+1-555-0102',
          referralCode: 'LEGEND01',
          rank: MemberRank.legend,
          level: 5,
          boardPosition: 6,
          directReferrals: ['demo-silver-1', 'demo-silver-2'],
          points: 500,
          walletBalance: 2500.0,
          earningWallet: 1200.0,
          joinDate: now.subtract(const Duration(days: 300)),
          isActive: true,
          isAdmin: false,
          stars: 5,
        ),
      ];
      
      await StorageService.saveMembers(defaultMembers);
      print('✅ Default members created successfully');
    } catch (e) {
      print('❌ Failed to create default members: $e');
    }
  }

  static Future<Member?> registerMember({
    required String name,
    required String email,
    required String phoneNumber,
    required String password,
    String? referralCode,
    String? profilePicture,
  }) async {
    try {
      print('🔄 Starting registration process for: $email');
      
      // Initialize storage if needed
      await StorageService.init();
      final members = StorageService.getMembers();
      
      // Check if email already exists
      if (members.any((m) => m.email.toLowerCase() == email.toLowerCase())) {
        print('❌ Registration failed: Email already exists');
        throw Exception('Email already exists');
      }

      String? referredBy;
      
      // Validate referral code if provided
      if (referralCode != null && referralCode.isNotEmpty) {
        final referrer = members.where((m) => m.referralCode == referralCode).firstOrNull;
        if (referrer == null) {
          print('❌ Registration failed: Invalid referral code');
          throw Exception('Invalid referral code');
        }
        referredBy = referrer.id;
        print('✅ Valid referral code from: ${referrer.name}');
      }

      // Create new member
      final newMember = Member(
        id: _uuid.v4(),
        name: name,
        email: email,
        phoneNumber: phoneNumber,
        referralCode: generateReferralCode(),
        referredBy: referredBy,
        rank: MemberRank.starter,
        level: 1,
        boardPosition: -1,
        directReferrals: [],
        points: 100, // Starting points
        walletBalance: 0.0,
        earningWallet: 0.0,
        joinDate: DateTime.now(),
        isActive: true,
        profilePicture: profilePicture,
        isAdmin: isAdministrator(email),
        stars: 1, // Starting with 1 star
      );

      // Save new member
      members.add(newMember);
      await StorageService.saveMembers(members);
      print('✅ Member saved successfully: ${newMember.name}');

      // Update referrer's direct referrals and award points
      if (referredBy != null) {
        await _updateReferrerReferrals(referredBy, newMember.id);
        await _awardReferralPoints(referredBy);
        print('✅ Updated referrer relationships and awarded points');
      }

      // Create welcome notifications for new member
      await NotificationService.createWelcomeNotifications(newMember.id, newMember.name);
      print('📱 Welcome notifications sent');

      print('🎉 Registration completed successfully for: ${newMember.name}');
      return newMember;
      
    } catch (e) {
      print('❌ Registration error: $e');
      return null;
    }
  }

  static Future<Member?> loginMember(String email, String password) async {
    try {
      print('🔄 Attempting login for: $email');
      
      // Initialize storage if needed
      await StorageService.init();
      final members = StorageService.getMembers();
      
      if (members.isEmpty) {
        print('⚠️ No members found, initializing sample data...');
        await _ensureDefaultMembers();
        final updatedMembers = StorageService.getMembers();
        if (updatedMembers.isEmpty) {
          print('❌ Failed to initialize members');
          return null;
        }
      }
      
      // Find member by email (case insensitive)
      final member = members.where((m) => 
        m.email.toLowerCase() == email.toLowerCase() && 
        m.isActive
      ).firstOrNull;
      
      if (member == null) {
        print('❌ Login failed: Member not found or inactive');
        print('📋 Available members: ${members.map((m) => m.email).join(', ')}');
        return null;
      }
      
      // For admin users and demo purposes, accept any password
      // In production, implement proper password hashing/verification
      if (isAdministrator(member.email) || 
          password == 'password123' ||
          password.isNotEmpty) {
        print('✅ Login successful for: ${member.name}');
        return member;
      } else {
        print('❌ Login failed: Invalid password');
        return null;
      }
      
    } catch (e) {
      print('❌ Login error: $e');
      return null;
    }
  }

  static Future<void> _updateReferrerReferrals(String referrerId, String newMemberId) async {
    final members = StorageService.getMembers();
    final referrerIndex = members.indexWhere((m) => m.id == referrerId);
    
    if (referrerIndex != -1) {
      final updatedReferrer = members[referrerIndex].copyWith(
        directReferrals: [...members[referrerIndex].directReferrals, newMemberId],
      );
      members[referrerIndex] = updatedReferrer;
      await StorageService.saveMembers(members);
      
      // Check for promotion after adding new referral
      await _checkAndPromoteMember(referrerId);
    }
  }

  // Award points for referrals
  static Future<void> _awardReferralPoints(String referrerId) async {
    final members = StorageService.getMembers();
    final referrerIndex = members.indexWhere((m) => m.id == referrerId);
    
    if (referrerIndex != -1) {
      final referrer = members[referrerIndex];
      final updatedReferrer = referrer.copyWith(
        points: referrer.points + 5, // 5 points for each referral
      );
      
      members[referrerIndex] = updatedReferrer;
      await StorageService.saveMembers(members);
      
      // Create points transaction
      await _createPointsTransaction(
        referrerId,
        5,
        'Referral bonus: +5 points for new team member',
      );
      
      print('✅ Awarded 5 points to referrer');
    }
  }

  // Promotion System - Check and promote members based on referral achievements
  static Future<void> _checkAndPromoteMember(String memberId) async {
    final members = StorageService.getMembers();
    final memberIndex = members.indexWhere((m) => m.id == memberId);
    
    if (memberIndex == -1) return;
    
    final member = members[memberIndex];
    final referrals = _getDirectReferralMembers(memberId, members);
    
    bool promoted = false;
    Member? promotedMember = member;
    
    // Promotion rules based on rank and referral achievements
    switch (member.rank) {
      case MemberRank.starter:
        // Promote to Bronze when has 2 direct referrals
        if (referrals.length >= 2) {
          promotedMember = member.copyWith(
            rank: MemberRank.bronze,
            points: member.points + 200, // Bonus points for promotion
          );
          promoted = true;
        }
        break;
        
      case MemberRank.bronze:
        // Promote to Silver when has 2 Bronze referrals
        final bronzeReferrals = referrals.where((r) => r.rank == MemberRank.bronze).length;
        if (bronzeReferrals >= 2) {
          promotedMember = member.copyWith(
            rank: MemberRank.silver,
            points: member.points + 500, // Bonus points for promotion
          );
          promoted = true;
        }
        break;
        
      case MemberRank.silver:
        // Promote to Legend Gold when has 2 Silver referrals
        final silverReferrals = referrals.where((r) => r.rank == MemberRank.silver).length;
        if (silverReferrals >= 2) {
          promotedMember = member.copyWith(
            rank: MemberRank.legend,
            points: member.points + 1000, // Bonus points for promotion
          );
          promoted = true;
        }
        break;
        
      case MemberRank.legend:
        // Legend Gold promotes to next level when board is completed
        // This is already handled in _completeBoardAndAdvanceMembers
        break;
    }
    
    if (promoted && promotedMember != null) {
      members[memberIndex] = promotedMember;
      await StorageService.saveMembers(members);
      
      // Create promotion transaction
      await _createPromotionTransaction(memberId, member.rank, promotedMember.rank);
      
      // Also check if the promoted member's referrer should be promoted
      if (member.referredBy != null) {
        await _checkAndPromoteMember(member.referredBy!);
      }
    }
  }
  
  // Get direct referral members
  static List<Member> _getDirectReferralMembers(String memberId, List<Member> allMembers) {
    final member = allMembers.firstWhere((m) => m.id == memberId, orElse: () => Member.empty());
    if (member.id == '') return [];
    
    return member.directReferrals
        .map((referralId) => allMembers.firstWhere((m) => m.id == referralId, orElse: () => Member.empty()))
        .where((m) => m.id != '')
        .toList();
  }
  
  // Create promotion transaction
  static Future<void> _createPromotionTransaction(String memberId, MemberRank fromRank, MemberRank toRank) async {
    final transactions = StorageService.getTransactions();
    final promotionBonus = _calculatePromotionBonus(toRank);
    
    final transaction = Transaction(
      id: _uuid.v4(),
      memberId: memberId,
      type: TransactionType.commission,
      amount: promotionBonus,
      currency: 'USD',
      status: TransactionStatus.completed,
      description: 'Promotion bonus: ${_getRankName(fromRank)} → ${_getRankName(toRank)}',
      createdAt: DateTime.now(),
      completedAt: DateTime.now(),
    );
    
    transactions.add(transaction);
    await StorageService.saveTransactions(transactions);
    
    // Update member wallet balance
    final members = StorageService.getMembers();
    final memberIndex = members.indexWhere((m) => m.id == memberId);
    if (memberIndex != -1) {
      members[memberIndex] = members[memberIndex].copyWith(
        walletBalance: members[memberIndex].walletBalance + promotionBonus,
      );
      await StorageService.saveMembers(members);
    }
  }
  
  // Calculate promotion bonus
  static double _calculatePromotionBonus(MemberRank rank) {
    switch (rank) {
      case MemberRank.bronze:
        return 25.0;
      case MemberRank.silver:
        return 75.0;
      case MemberRank.legend:
        return 200.0;
      default:
        return 0.0;
    }
  }
  
  // Get rank name for display
  static String _getRankName(MemberRank rank) {
    switch (rank) {
      case MemberRank.starter:
        return 'Starter';
      case MemberRank.bronze:
        return 'Bronze';
      case MemberRank.silver:
        return 'Silver';
      case MemberRank.legend:
        return 'Legend Gold';
    }
  }

  static Future<MLMBoard> assignMemberToBoard(String memberId) async {
    final boards = StorageService.getBoards();
    final members = StorageService.getMembers();
    final member = members.firstWhere((m) => m.id == memberId);
    
    // Find available board at member's level
    MLMBoard? availableBoard = boards.cast<MLMBoard?>().firstWhere(
      (board) => board != null && board.level == member.level && !board.isComplete && board.filledPositions < 14,
      orElse: () => null,
    );

    // Create new board if none available
    if (availableBoard == null) {
      availableBoard = MLMBoard.empty(_uuid.v4(), member.level);
      boards.add(availableBoard);
    }

    // Assign member to next available position
    final nextPosition = availableBoard.positions.indexWhere((pos) => pos.memberId == null);
    if (nextPosition != -1) {
      final updatedPositions = List<BoardPosition>.from(availableBoard.positions);
      updatedPositions[nextPosition] = BoardPosition(
        position: nextPosition,
        memberId: memberId,
        memberName: member.name,
      );

      final updatedBoard = availableBoard.copyWith(positions: updatedPositions);
      final boardIndex = boards.indexWhere((b) => b.id == availableBoard!.id);
      boards[boardIndex] = updatedBoard;

      // Update member's board assignment
      final memberIndex = members.indexWhere((m) => m.id == memberId);
      members[memberIndex] = member.copyWith(
        boardId: updatedBoard.id,
        boardPosition: nextPosition,
      );

      await StorageService.saveBoards(boards);
      await StorageService.saveMembers(members);

      // Check if board is complete
      if (updatedBoard.filledPositions == 14) {
        await _completeBoardAndAdvanceMembers(updatedBoard);
      }

      return updatedBoard;
    }

    throw Exception('No available positions on board');
  }

  static Future<void> _completeBoardAndAdvanceMembers(MLMBoard board) async {
    final members = StorageService.getMembers();
    final boards = StorageService.getBoards();
    
    // Mark board as complete
    final boardIndex = boards.indexWhere((b) => b.id == board.id);
    boards[boardIndex] = board.copyWith(isComplete: true);
    
    // Process board completion and recycling
    await _processBoardCompletion(board, members, boards);
    
    await StorageService.saveBoards(boards);
    await StorageService.saveMembers(members);
  }

  static Future<void> _processBoardCompletion(MLMBoard board, List<Member> members, List<MLMBoard> boards) async {
    // Find the legend member (center position)
    final legendPosition = board.positions.firstWhere(
      (pos) => pos.position == 6, // Position 6 is middle legend
      orElse: () => BoardPosition(position: -1),
    );
    
    if (legendPosition.memberId == null) return;
    
    final legendMember = members.firstWhere((m) => m.id == legendPosition.memberId);
    final legendIndex = members.indexWhere((m) => m.id == legendPosition.memberId);
    
    // Award completion bonus to legend
    await _createCommissionTransaction(legendMember.id, board.level);
    
    // Create recycled board for legend member with their referral team
    if (legendMember.level < 7) {
      await _recycleBoardForLegend(legendMember, members, boards);
      
      // Advance legend to next level
      members[legendIndex] = legendMember.copyWith(
        level: legendMember.level + 1,
        boardId: null,
        boardPosition: -1,
      );
    }
    
    // Clear other members from completed board for reassignment
    await _clearAndReassignBoardMembers(board, members, boards, legendPosition.memberId!);
  }

  static Future<void> _recycleBoardForLegend(Member legendMember, List<Member> members, List<MLMBoard> boards) async {
    // Create new board at legend's new level
    final newLevel = legendMember.level + 1;
    final recycledBoard = MLMBoard.empty(_uuid.v4(), newLevel);
    
    // Place legend member in center position (position 6)
    final updatedPositions = List<BoardPosition>.from(recycledBoard.positions);
    updatedPositions[6] = BoardPosition(
      position: 6,
      memberId: legendMember.id,
      memberName: legendMember.name,
    );
    
    final boardWithLegend = recycledBoard.copyWith(positions: updatedPositions);
    boards.add(boardWithLegend);
    
    // Update legend's board assignment
    final legendIndex = members.indexWhere((m) => m.id == legendMember.id);
    members[legendIndex] = members[legendIndex].copyWith(
      boardId: boardWithLegend.id,
      boardPosition: 6,
    );
    
    // Fill board with legend's referral team members who are ready to advance
    await _fillRecycledBoardWithReferrals(boardWithLegend, legendMember, members, boards);
  }

  static Future<void> _fillRecycledBoardWithReferrals(MLMBoard board, Member legendMember, List<Member> members, List<MLMBoard> boards) async {
    // Get all referral team members (direct and indirect referrals)
    final referralTeam = _getReferralTeamMembers(legendMember.id, members);
    
    // Filter members eligible for this board level
    final eligibleMembers = referralTeam.where((member) => 
      member.level >= board.level - 1 && // Can be one level below board level
      (member.boardId == null || member.boardPosition == -1) && // Not currently on a board
      member.isActive
    ).toList();
    
    // Sort by join date (oldest first) and then by level (highest first)
    eligibleMembers.sort((a, b) {
      if (a.level != b.level) return b.level.compareTo(a.level);
      return a.joinDate.compareTo(b.joinDate);
    });
    
    // Fill available positions (skip position 6 which is legend)
    final updatedPositions = List<BoardPosition>.from(board.positions);
    int memberIndex = 0;
    
    for (int position = 0; position < 14; position++) {
      if (position == 6) continue; // Skip legend position
      
      if (memberIndex < eligibleMembers.length) {
        final member = eligibleMembers[memberIndex];
        updatedPositions[position] = BoardPosition(
          position: position,
          memberId: member.id,
          memberName: member.name,
        );
        
        // Update member's board assignment
        final memberIdx = members.indexWhere((m) => m.id == member.id);
        members[memberIdx] = members[memberIdx].copyWith(
          boardId: board.id,
          boardPosition: position,
        );
        
        memberIndex++;
      }
    }
    
    // Update board with new positions
    final boardIndex = boards.indexWhere((b) => b.id == board.id);
    boards[boardIndex] = board.copyWith(positions: updatedPositions);
  }

  static List<Member> _getReferralTeamMembers(String memberId, List<Member> allMembers) {
    final member = allMembers.firstWhere((m) => m.id == memberId, orElse: () => Member.empty());
    if (member.id == '') return [];
    
    List<Member> teamMembers = [];
    
    // Add direct referrals
    for (final referralId in member.directReferrals) {
      try {
        final referral = allMembers.firstWhere((m) => m.id == referralId);
        teamMembers.add(referral);
        // Recursively add their referrals (up to 3 levels deep)
        teamMembers.addAll(_getReferralTeamMembers(referralId, allMembers));
      } catch (e) {
        // Member not found, skip
      }
    }
    
    return teamMembers;
  }

  static Future<void> _clearAndReassignBoardMembers(MLMBoard completedBoard, List<Member> members, List<MLMBoard> boards, String legendMemberId) async {
    // Clear board positions for all members except legend
    for (final position in completedBoard.positions) {
      if (position.memberId != null && position.memberId != legendMemberId) {
        final memberIndex = members.indexWhere((m) => m.id == position.memberId);
        if (memberIndex != -1) {
          // Clear board assignment
          members[memberIndex] = members[memberIndex].copyWith(
            boardId: null,
            boardPosition: -1,
          );
          
          // Try to reassign to appropriate level board
          try {
            await assignMemberToBoard(position.memberId!);
          } catch (e) {
            // If no board available, member will be assigned when board becomes available
            print('⚠️ Could not immediately reassign member ${members[memberIndex].name} to new board');
          }
        }
      }
    }
  }

  static Future<void> _createCommissionTransaction(String memberId, int level) async {
    final transactions = StorageService.getTransactions();
    final commissionAmount = _calculateCommission(level);
    
    final transaction = Transaction(
      id: _uuid.v4(),
      memberId: memberId,
      type: TransactionType.commission,
      amount: commissionAmount,
      currency: 'USD',
      status: TransactionStatus.completed,
      description: 'Board completion commission - Level $level',
      createdAt: DateTime.now(),
      completedAt: DateTime.now(),
    );
    
    transactions.add(transaction);
    await StorageService.saveTransactions(transactions);
    
    // Update member wallet balance
    final members = StorageService.getMembers();
    final memberIndex = members.indexWhere((m) => m.id == memberId);
    if (memberIndex != -1) {
      members[memberIndex] = members[memberIndex].copyWith(
        walletBalance: members[memberIndex].walletBalance + commissionAmount,
      );
      await StorageService.saveMembers(members);
    }
  }

  static double _calculateCommission(int level) {
    // Commission structure based on level
    switch (level) {
      case 1: return 50.0;
      case 2: return 100.0;
      case 3: return 250.0;
      case 4: return 500.0;
      case 5: return 1000.0;
      case 6: return 2500.0;
      case 7: return 5000.0;
      default: return 50.0;
    }
  }

  static List<Member> getNetworkMembers(String memberId) {
    final members = StorageService.getMembers();
    final member = members.firstWhere((m) => m.id == memberId);
    
    List<Member> networkMembers = [];
    
    // Get direct referrals
    for (final referralId in member.directReferrals) {
      try {
        final referral = members.firstWhere((m) => m.id == referralId);
        networkMembers.add(referral);
        // Get indirect referrals (down to 3 levels)
        networkMembers.addAll(_getIndirectReferrals(referralId, members, 2));
      } catch (e) {
        // Member not found, skip
      }
    }
    
    return networkMembers;
  }

  static List<Member> _getIndirectReferrals(String memberId, List<Member> allMembers, int depth) {
    if (depth <= 0) return [];
    
    final member = allMembers.firstWhere((m) => m.id == memberId, orElse: () => throw Exception());
    List<Member> indirectReferrals = [];
    
    for (final referralId in member.directReferrals) {
      try {
        final referral = allMembers.firstWhere((m) => m.id == referralId);
        indirectReferrals.add(referral);
        indirectReferrals.addAll(_getIndirectReferrals(referralId, allMembers, depth - 1));
      } catch (e) {
        // Member not found, skip
      }
    }
    
    return indirectReferrals;
  }

  // Board Join Request Methods
  static Future<BoardJoinRequest> createBoardJoinRequest({
    required String memberId,
    required int requestedLevel,
    required String paymentMethod,
    String? paymentProof,
    double? depositAmount,
    required String accountId,
    required String accountName,
  }) async {
    final members = StorageService.getMembers();
    final member = members.firstWhere((m) => m.id == memberId);
    final finalDepositAmount = depositAmount ?? 1.0;
    
    final request = BoardJoinRequest(
      id: _uuid.v4(),
      memberId: memberId,
      memberName: member.name,
      memberEmail: member.email,
      memberPhone: member.phoneNumber,
      requestedLevel: requestedLevel,
      paymentAmount: finalDepositAmount,
      paymentMethod: paymentMethod,
      paymentProof: paymentProof,
      accountId: accountId,
      accountName: accountName,
      status: ApprovalStatus.pending,
      requestDate: DateTime.now(),
    );

    final requests = StorageService.getBoardJoinRequests();
    requests.add(request);
    await StorageService.saveBoardJoinRequests(requests);

    // Update member's deposit and board join status
    final memberIndex = members.indexWhere((m) => m.id == memberId);
    if (memberIndex != -1) {
      final currentDeposit = members[memberIndex].depositAmount;
      final newTotalDeposit = currentDeposit + finalDepositAmount;
      
      members[memberIndex] = member.copyWith(
        boardJoinStatus: ApprovalStatus.pending,
        paymentProof: paymentProof,
        depositAmount: newTotalDeposit,
        hasMinimumDeposit: newTotalDeposit >= 1.0,
      );
    }
    await StorageService.saveMembers(members);

    return request;
  }

  static Future<void> approveJoinRequest(String requestId, String adminId) async {
    final requests = StorageService.getBoardJoinRequests();
    final requestIndex = requests.indexWhere((r) => r.id == requestId);
    
    if (requestIndex == -1) throw Exception('Request not found');
    
    final request = requests[requestIndex];
    final approvedRequest = request.copyWith(
      status: ApprovalStatus.approved,
      approvalDate: DateTime.now(),
      approvedBy: adminId,
    );
    
    requests[requestIndex] = approvedRequest;
    await StorageService.saveBoardJoinRequests(requests);

    // Update member status and assign to board
    final members = StorageService.getMembers();
    final memberIndex = members.indexWhere((m) => m.id == request.memberId);
    
    if (memberIndex != -1) {
      final currentMember = members[memberIndex];
      members[memberIndex] = currentMember.copyWith(
        boardJoinStatus: ApprovalStatus.approved,
        approvalDate: DateTime.now(),
        level: request.requestedLevel,
        hasMinimumDeposit: currentMember.depositAmount >= 1.0,
      );
      await StorageService.saveMembers(members);
      
      // Only assign to board if member has minimum deposit and is approved
      if (currentMember.depositAmount >= 1.0) {
        await assignMemberToBoard(request.memberId);
        
        // Distribute referral profits to upline
        await distributeReferralProfits(request.memberId, request.paymentAmount);
        
        // Check if this member's referrer should be promoted
        if (currentMember.referredBy != null) {
          await _checkAndPromoteMember(currentMember.referredBy!);
        }
      }
      
      // Send approval notification
      await NotificationService.createBoardApprovalNotification(
        request.memberId,
        request.memberName,
        request.requestedLevel,
        request.paymentAmount,
      );
      
      // Send level progress notification
      await NotificationService.createLevelUpNotification(
        request.memberId,
        request.memberName,
        request.requestedLevel,
        _getRankName(members[memberIndex].rank),
      );
      
      // Create progress report for admin
      await _createProgressReport(request.memberId, 'Board Join Approved', {
        'action': 'board_join_approval',
        'level': request.requestedLevel,
        'amount': request.paymentAmount,
        'timestamp': DateTime.now().toIso8601String(),
      });
      
      print('📱 Board approval notification sent to ${request.memberName}');
    }
  }

  static Future<void> rejectJoinRequest(String requestId, String adminId, String reason) async {
    final requests = StorageService.getBoardJoinRequests();
    final requestIndex = requests.indexWhere((r) => r.id == requestId);
    
    if (requestIndex == -1) throw Exception('Request not found');
    
    final request = requests[requestIndex];
    final rejectedRequest = request.copyWith(
      status: ApprovalStatus.rejected,
      approvalDate: DateTime.now(),
      approvedBy: adminId,
      rejectionReason: reason,
    );
    
    requests[requestIndex] = rejectedRequest;
    await StorageService.saveBoardJoinRequests(requests);

    // Update member status
    final members = StorageService.getMembers();
    final memberIndex = members.indexWhere((m) => m.id == request.memberId);
    
    if (memberIndex != -1) {
      members[memberIndex] = members[memberIndex].copyWith(
        boardJoinStatus: ApprovalStatus.rejected,
        approvalDate: DateTime.now(),
      );
      await StorageService.saveMembers(members);
    }
    
    // Send rejection notification
    await NotificationService.createBoardRejectionNotification(
      request.memberId,
      request.memberName,
      request.requestedLevel,
      request.paymentAmount,
      reason,
    );
    print('📱 Board rejection notification sent to ${request.memberName}');
  }

  static List<BoardJoinRequest> getPendingJoinRequests() {
    final requests = StorageService.getBoardJoinRequests();
    return requests.where((r) => r.status == ApprovalStatus.pending).toList();
  }

  static List<BoardJoinRequest> getJoinRequestHistory() {
    return StorageService.getBoardJoinRequests();
  }

  // Internal money transfer between users
  static Future<bool> transferMoney({
    required String fromMemberId,
    required String toMemberEmail,
    required double amount,
    String? note,
  }) async {
    final members = StorageService.getMembers();
    final fromMemberIndex = members.indexWhere((m) => m.id == fromMemberId);
    final toMemberIndex = members.indexWhere((m) => m.email.toLowerCase() == toMemberEmail.toLowerCase());
    
    if (fromMemberIndex == -1 || toMemberIndex == -1) {
      throw Exception('Member not found');
    }
    
    final fromMember = members[fromMemberIndex];
    final toMember = members[toMemberIndex];
    
    if (fromMember.walletBalance < amount) {
      throw Exception('Insufficient balance');
    }
    
    if (amount <= 0) {
      throw Exception('Amount must be greater than 0');
    }
    
    // Update balances
    members[fromMemberIndex] = fromMember.copyWith(
      walletBalance: fromMember.walletBalance - amount,
    );
    
    members[toMemberIndex] = toMember.copyWith(
      walletBalance: toMember.walletBalance + amount,
    );
    
    await StorageService.saveMembers(members);
    
    // Create transfer transactions
    final transactions = StorageService.getTransactions();
    final transferNote = note ?? 'Transfer to ${toMember.name}';
    
    // Outgoing transaction for sender
    transactions.add(Transaction(
      id: _uuid.v4(),
      memberId: fromMemberId,
      type: TransactionType.withdrawal,
      amount: amount,
      currency: 'USD',
      status: TransactionStatus.completed,
      description: 'Transfer sent to ${toMember.name}: $transferNote',
      createdAt: DateTime.now(),
      completedAt: DateTime.now(),
    ));
    
    // Incoming transaction for receiver
    transactions.add(Transaction(
      id: _uuid.v4(),
      memberId: toMember.id,
      type: TransactionType.deposit,
      amount: amount,
      currency: 'USD',
      status: TransactionStatus.completed,
      description: 'Transfer received from ${fromMember.name}: $transferNote',
      createdAt: DateTime.now(),
      completedAt: DateTime.now(),
    ));
    
    await StorageService.saveTransactions(transactions);
    return true;
  }

  // Withdrawal Request Methods
  static Future<WithdrawalRequest> createWithdrawalRequest({
    required String memberId,
    required double amount,
    required String paymentMethod,
    required String accountId,
    required String accountName,
  }) async {
    final members = StorageService.getMembers();
    final member = members.firstWhere((m) => m.id == memberId);
    
    if (member.walletBalance < amount) {
      throw Exception('Insufficient balance');
    }
    
    final request = WithdrawalRequest(
      id: _uuid.v4(),
      memberId: memberId,
      memberName: member.name,
      memberEmail: member.email,
      memberPhone: member.phoneNumber,
      amount: amount,
      paymentMethod: paymentMethod,
      accountId: accountId,
      accountName: accountName,
      status: ApprovalStatus.pending,
      requestDate: DateTime.now(),
    );

    final requests = StorageService.getWithdrawalRequests();
    requests.add(request);
    await StorageService.saveWithdrawalRequests(requests);

    return request;
  }

  static Future<void> approveWithdrawalRequest(String requestId, String adminId) async {
    final requests = StorageService.getWithdrawalRequests();
    final requestIndex = requests.indexWhere((r) => r.id == requestId);
    
    if (requestIndex == -1) throw Exception('Request not found');
    
    final request = requests[requestIndex];
    final approvedRequest = request.copyWith(
      status: ApprovalStatus.approved,
      approvalDate: DateTime.now(),
      approvedBy: adminId,
    );
    
    requests[requestIndex] = approvedRequest;
    await StorageService.saveWithdrawalRequests(requests);

    // Update member wallet balance
    final members = StorageService.getMembers();
    final memberIndex = members.indexWhere((m) => m.id == request.memberId);
    
    if (memberIndex != -1) {
      final currentBalance = members[memberIndex].walletBalance;
      members[memberIndex] = members[memberIndex].copyWith(
        walletBalance: currentBalance - request.amount,
      );
      await StorageService.saveMembers(members);
      
      // Create withdrawal transaction
      final transactions = StorageService.getTransactions();
      transactions.add(Transaction(
        id: _uuid.v4(),
        memberId: request.memberId,
        type: TransactionType.withdrawal,
        amount: request.amount,
        currency: 'USD',
        status: TransactionStatus.completed,
        description: 'Withdrawal via ${request.paymentMethod}',
        createdAt: DateTime.now(),
        completedAt: DateTime.now(),
      ));
      await StorageService.saveTransactions(transactions);
      
      // Send approval notification
      await NotificationService.createWithdrawalApprovalNotification(
        request.memberId,
        request.memberName,
        request.amount,
        request.paymentMethod,
      );
      print('📱 Withdrawal approval notification sent to ${request.memberName}');
    }
  }

  static Future<void> rejectWithdrawalRequest(String requestId, String adminId, String reason) async {
    final requests = StorageService.getWithdrawalRequests();
    final requestIndex = requests.indexWhere((r) => r.id == requestId);
    
    if (requestIndex == -1) throw Exception('Request not found');
    
    final request = requests[requestIndex];
    final rejectedRequest = request.copyWith(
      status: ApprovalStatus.rejected,
      approvalDate: DateTime.now(),
      approvedBy: adminId,
      rejectionReason: reason,
    );
    
    requests[requestIndex] = rejectedRequest;
    await StorageService.saveWithdrawalRequests(requests);
    
    // Send rejection notification
    await NotificationService.createWithdrawalRejectionNotification(
      request.memberId,
      request.memberName,
      request.amount,
      reason,
    );
    print('📱 Withdrawal rejection notification sent to ${request.memberName}');
  }

  static List<WithdrawalRequest> getPendingWithdrawalRequests() {
    final requests = StorageService.getWithdrawalRequests();
    return requests.where((r) => r.status == ApprovalStatus.pending).toList();
  }

  static List<WithdrawalRequest> getWithdrawalRequestHistory() {
    return StorageService.getWithdrawalRequests();
  }

  // Generate referral link
  static String generateReferralLink(String referralCode) {
    return 'https://go-win-international.com/register?ref=$referralCode';
  }

  // Public method to manually check promotions (for testing or admin purposes)
  static Future<void> checkMemberForPromotion(String memberId) async {
    await _checkAndPromoteMember(memberId);
  }

  // Referral Profit Distribution System
  static Future<void> distributeReferralProfits(String newMemberId, double depositAmount) async {
    final members = StorageService.getMembers();
    final newMember = members.firstWhere((m) => m.id == newMemberId, orElse: () => Member.empty());
    
    if (newMember.referredBy == null) return;
    
    final referrer = members.firstWhere((m) => m.id == newMember.referredBy);
    await _distributeProfitUpward(referrer.id, depositAmount, 1, members);
  }
  
  static Future<void> _distributeProfitUpward(String memberId, double baseAmount, int level, List<Member> members) async {
    if (level > 3) return; // Only distribute up to 3 levels
    
    final member = members.firstWhere((m) => m.id == memberId, orElse: () => Member.empty());
    if (member.id == '') return;
    
    double profitPercentage;
    String levelDescription;
    
    // Distribution rules: 100% from 2 direct, 75% from 4 below, 50% from 4 others
    if (level == 1) {
      profitPercentage = 1.0; // 100% from direct referrals
      levelDescription = "Direct referral profit";
    } else if (level == 2) {
      profitPercentage = 0.75; // 75% from second level
      levelDescription = "2nd level referral profit";
    } else {
      profitPercentage = 0.50; // 50% from third level
      levelDescription = "3rd level referral profit";
    }
    
    final profitAmount = baseAmount * profitPercentage;
    
    // Update member's earning wallet
    final memberIndex = members.indexWhere((m) => m.id == memberId);
    if (memberIndex != -1) {
      members[memberIndex] = members[memberIndex].copyWith(
        earningWallet: members[memberIndex].earningWallet + profitAmount,
      );
      
      // Create profit transaction
      await _createReferralProfitTransaction(memberId, profitAmount, levelDescription, level);
    }
    
    // Continue to next level if member has referrer
    if (member.referredBy != null) {
      await _distributeProfitUpward(member.referredBy!, baseAmount, level + 1, members);
    }
  }
  
  static Future<void> _createReferralProfitTransaction(String memberId, double amount, String description, int level) async {
    final transactions = StorageService.getTransactions();
    
    final transaction = Transaction(
      id: _uuid.v4(),
      memberId: memberId,
      type: TransactionType.referralProfit,
      amount: amount,
      currency: 'USD',
      status: TransactionStatus.completed,
      description: '$description (${(level == 1 ? 100 : level == 2 ? 75 : 50)}%)',
      createdAt: DateTime.now(),
      completedAt: DateTime.now(),
      metadata: {'level': level, 'percentage': level == 1 ? 100 : level == 2 ? 75 : 50},
    );
    
    transactions.add(transaction);
    await StorageService.saveTransactions(transactions);
    await StorageService.saveMembers(StorageService.getMembers());
  }

  // Level Upgrade System
  static double getLevelUpgradeCost(int currentLevel) {
    switch (currentLevel + 1) {
      case 2: return 5.0;
      case 3: return 10.0;
      case 4: return 20.0;
      case 5: return 50.0;
      case 6: return 100.0;
      case 7: return 200.0;
      default: return 0.0;
    }
  }
  
  static bool canUpgradeLevel(String memberId) {
    final members = StorageService.getMembers();
    final member = members.firstWhere((m) => m.id == memberId, orElse: () => Member.empty());
    
    if (member.id == '' || member.level >= 7) return false;
    
    final upgradeCost = getLevelUpgradeCost(member.level);
    return member.earningWallet >= upgradeCost;
  }
  
  static Future<bool> upgradeLevel(String memberId) async {
    final members = StorageService.getMembers();
    final memberIndex = members.indexWhere((m) => m.id == memberId);
    
    if (memberIndex == -1) return false;
    
    final member = members[memberIndex];
    final upgradeCost = getLevelUpgradeCost(member.level);
    
    if (member.level >= 7 || member.earningWallet < upgradeCost) {
      return false;
    }
    
    // Deduct cost from earning wallet and upgrade level with bonus points and stars
    final upgradedMember = member.copyWith(
      level: member.level + 1,
      earningWallet: member.earningWallet - upgradeCost,
      points: member.points + 20, // 20 points for each level upgrade
      stars: member.level + 1, // One star for each level (1-7 stars)
    );
    
    members[memberIndex] = upgradedMember;
    await StorageService.saveMembers(members);
    
    // Create upgrade transaction
    await _createLevelUpgradeTransaction(memberId, upgradeCost, member.level, member.level + 1);
    
    // Award level upgrade points
    await _createPointsTransaction(
      memberId,
      20,
      'Level upgrade bonus: +20 points for reaching Level ${member.level + 1}',
    );
    
    return true;
  }
  
  static Future<void> _createLevelUpgradeTransaction(String memberId, double cost, int fromLevel, int toLevel) async {
    final transactions = StorageService.getTransactions();
    
    final transaction = Transaction(
      id: _uuid.v4(),
      memberId: memberId,
      type: TransactionType.levelUpgrade,
      amount: cost,
      currency: 'USD',
      status: TransactionStatus.completed,
      description: 'Level upgrade: Level $fromLevel → Level $toLevel',
      createdAt: DateTime.now(),
      completedAt: DateTime.now(),
      metadata: {'fromLevel': fromLevel, 'toLevel': toLevel},
    );
    
    transactions.add(transaction);
    await StorageService.saveTransactions(transactions);
  }
  
  // Create points transaction
  static Future<void> _createPointsTransaction(String memberId, int points, String description) async {
    final transactions = StorageService.getTransactions();
    
    final transaction = Transaction(
      id: _uuid.v4(),
      memberId: memberId,
      type: TransactionType.referralBonus, // Reusing for points
      amount: points.toDouble(),
      currency: 'PTS', // Points currency
      status: TransactionStatus.completed,
      description: description,
      createdAt: DateTime.now(),
      completedAt: DateTime.now(),
      metadata: {'pointsAwarded': points},
    );
    
    transactions.add(transaction);
    await StorageService.saveTransactions(transactions);
  }
  
  // Check if user can withdraw (must pay for next level upgrade first)
  static bool canWithdraw(String memberId) {
    final members = StorageService.getMembers();
    final member = members.firstWhere((m) => m.id == memberId, orElse: () => Member.empty());
    
    if (member.id == '') return false;
    
    // Members can withdraw after paying for next level or being at max level
    return member.hasNextLevelPayment || member.level >= 7;
  }
  
  static String getWithdrawalRestrictionMessage(String memberId) {
    if (canWithdraw(memberId)) return '';
    
    final members = StorageService.getMembers();
    final member = members.firstWhere((m) => m.id == memberId, orElse: () => Member.empty());
    
    if (member.id == '') return 'Member not found';
    if (member.level >= 7) return '';
    
    if (!member.hasNextLevelPayment) {
      final nextLevelCost = getLevelUpgradeCost(member.level);
      return 'You must pay \$${nextLevelCost.toStringAsFixed(2)} for next level before withdrawing. Click "Pay Next Level" to unlock withdrawal.';
    }
    
    return 'Withdrawal not available';
  }
  
  static bool canPayNextLevel(String memberId) {
    final members = StorageService.getMembers();
    final member = members.firstWhere((m) => m.id == memberId, orElse: () => Member.empty());
    
    if (member.id == '') return false;
    
    // Can pay next level if not at max level and hasn't paid for next level yet
    return member.level < 7 && !member.hasNextLevelPayment && 
           member.earningWallet >= getLevelUpgradeCost(member.level);
  }
  
  static Future<bool> payNextLevel(String memberId) async {
    final members = StorageService.getMembers();
    final memberIndex = members.indexWhere((m) => m.id == memberId);
    
    if (memberIndex == -1) return false;
    
    final member = members[memberIndex];
    final cost = getLevelUpgradeCost(member.level);
    
    if (member.earningWallet < cost || member.hasNextLevelPayment) {
      return false;
    }
    
    // Deduct cost from earning wallet and mark as paid
    final updatedMember = member.copyWith(
      earningWallet: member.earningWallet - cost,
      hasNextLevelPayment: true,
    );
    
    members[memberIndex] = updatedMember;
    await StorageService.saveMembers(members);
    
    // Record transaction
    final transaction = Transaction(
      id: _uuid.v4(),
      memberId: memberId,
      type: TransactionType.levelUpgrade,
      amount: cost,
      currency: 'USD',
      status: TransactionStatus.completed,
      description: 'Next Level Payment - Level ${member.level + 1}',
      createdAt: DateTime.now(),
      completedAt: DateTime.now(),
    );
    
    final transactions = StorageService.getTransactions();
    transactions.add(transaction);
    await StorageService.saveTransactions(transactions);
    
    // Update current member if this is them
    final currentMember = StorageService.getCurrentMember();
    if (currentMember?.id == memberId) {
      await StorageService.saveCurrentMember(updatedMember);
    }
    
    return true;
  }

  // Create progress report for admin tracking
  static Future<void> _createProgressReport(String memberId, String action, Map<String, dynamic> data) async {
    try {
      final reports = StorageService.getProgressReports() ?? [];
      final members = StorageService.getMembers();
      final member = members.firstWhere((m) => m.id == memberId, orElse: () => Member.empty());
      
      if (member.id.isNotEmpty) {
        final report = {
          'id': _uuid.v4(),
          'memberId': memberId,
          'memberName': member.name,
          'memberEmail': member.email,
          'action': action,
          'data': data,
          'timestamp': DateTime.now().toIso8601String(),
          'level': member.level,
          'rank': _getRankName(member.rank),
        };
        
        reports.add(report);
        await StorageService.saveProgressReports(reports);
        print('📊 Progress report created: $action for ${member.name}');
      }
    } catch (e) {
      print('❌ Failed to create progress report: $e');
    }
  }

  // Get all members for admin view
  static List<Member> getAllMembers() {
    return StorageService.getMembers();
  }

  // View member profile by admin
  static Member? viewMemberProfile(String memberId) {
    final members = StorageService.getMembers();
    return members.firstWhere((m) => m.id == memberId, orElse: () => Member.empty());
  }

  // Update member information by admin
  static Future<bool> updateMemberInfo(String memberId, Map<String, dynamic> updates) async {
    try {
      final members = StorageService.getMembers();
      final memberIndex = members.indexWhere((m) => m.id == memberId);
      
      if (memberIndex == -1) return false;
      
      final member = members[memberIndex];
      Member updatedMember = member;
      
      // Apply updates
      if (updates.containsKey('name')) updatedMember = updatedMember.copyWith(name: updates['name']);
      if (updates.containsKey('email')) updatedMember = updatedMember.copyWith(email: updates['email']);
      if (updates.containsKey('phoneNumber')) updatedMember = updatedMember.copyWith(phoneNumber: updates['phoneNumber']);
      if (updates.containsKey('level')) updatedMember = updatedMember.copyWith(level: updates['level']);
      if (updates.containsKey('walletBalance')) updatedMember = updatedMember.copyWith(walletBalance: updates['walletBalance'].toDouble());
      if (updates.containsKey('earningWallet')) updatedMember = updatedMember.copyWith(earningWallet: updates['earningWallet'].toDouble());
      if (updates.containsKey('isActive')) updatedMember = updatedMember.copyWith(isActive: updates['isActive']);
      
      members[memberIndex] = updatedMember;
      await StorageService.saveMembers(members);
      
      // Create update report
      await _createProgressReport(memberId, 'Profile Updated by Admin', {
        'updates': updates,
        'updatedBy': 'admin',
        'timestamp': DateTime.now().toIso8601String(),
      });
      
      return true;
    } catch (e) {
      print('❌ Failed to update member info: $e');
      return false;
    }
  }

  // Get member earning reports
  static Map<String, dynamic> getMemberEarningReport(String memberId) {
    final members = StorageService.getMembers();
    final transactions = StorageService.getTransactions();
    final member = members.firstWhere((m) => m.id == memberId, orElse: () => Member.empty());
    
    if (member.id.isEmpty) return {};
    
    final memberTransactions = transactions.where((t) => t.memberId == memberId).toList();
    final commissions = memberTransactions.where((t) => t.type == TransactionType.commission).fold(0.0, (sum, t) => sum + t.amount);
    final referralProfits = memberTransactions.where((t) => t.type == TransactionType.referralProfit).fold(0.0, (sum, t) => sum + t.amount);
    final deposits = memberTransactions.where((t) => t.type == TransactionType.deposit).fold(0.0, (sum, t) => sum + t.amount);
    final withdrawals = memberTransactions.where((t) => t.type == TransactionType.withdrawal).fold(0.0, (sum, t) => sum + t.amount);
    
    return {
      'member': member,
      'totalEarnings': commissions + referralProfits,
      'commissions': commissions,
      'referralProfits': referralProfits,
      'deposits': deposits,
      'withdrawals': withdrawals,
      'netProfit': (commissions + referralProfits + deposits) - withdrawals,
      'transactionCount': memberTransactions.length,
      'lastTransaction': memberTransactions.isNotEmpty ? memberTransactions.last.createdAt : null,
    };
  }

  // Send notification for progress updates
  static Future<void> notifyProgressUpdate(String memberId, String progressType, Map<String, dynamic> data) async {
    final members = StorageService.getMembers();
    final member = members.firstWhere((m) => m.id == memberId, orElse: () => Member.empty());
    
    if (member.id.isEmpty) return;
    
    String title = '';
    String message = '';
    NotificationType type = NotificationType.general;
    
    switch (progressType) {
      case 'level_upgrade':
        title = '🎉 Level Upgrade!';
        message = 'Congratulations! You\'ve advanced to Level ${data['newLevel']}! New earning opportunities await you.';
        type = NotificationType.levelUp;
        break;
      case 'board_complete':
        title = '🏆 Board Completed!';
        message = 'Amazing! You\'ve completed your Level ${data['level']} board and earned \$${data['commission']}!';
        type = NotificationType.boardApproval;
        break;
      case 'earning_milestone':
        title = '💰 Earning Milestone!';
        message = 'Fantastic! You\'ve reached \$${data['amount']} in total earnings!';
        type = NotificationType.general;
        break;
      case 'referral_achievement':
        title = '👥 Referral Achievement!';
        message = 'Great job! You now have ${data['count']} active referrals in your network!';
        type = NotificationType.referralBonus;
        break;
    }
    
    await NotificationService.createNotification(
      memberId: memberId,
      title: title,
      message: message,
      type: type,
      data: data,
    );
  }

  // Get promotion progress for a member
  static Map<String, dynamic> getPromotionProgress(String memberId) {
    final members = StorageService.getMembers();
    final member = members.firstWhere((m) => m.id == memberId, orElse: () => Member.empty());
    if (member.id == '') return {};
    
    final referrals = _getDirectReferralMembers(memberId, members);
    
    switch (member.rank) {
      case MemberRank.starter:
        return {
          'currentRank': 'Starter',
          'nextRank': 'Bronze',
          'requirement': 'Need 2 direct referrals',
          'progress': referrals.length,
          'target': 2,
          'canPromote': referrals.length >= 2,
        };
        
      case MemberRank.bronze:
        final bronzeReferrals = referrals.where((r) => r.rank == MemberRank.bronze).length;
        return {
          'currentRank': 'Bronze',
          'nextRank': 'Silver',
          'requirement': 'Need 2 Bronze referrals',
          'progress': bronzeReferrals,
          'target': 2,
          'canPromote': bronzeReferrals >= 2,
        };
        
      case MemberRank.silver:
        final silverReferrals = referrals.where((r) => r.rank == MemberRank.silver).length;
        return {
          'currentRank': 'Silver',
          'nextRank': 'Legend Gold',
          'requirement': 'Need 2 Silver referrals',
          'progress': silverReferrals,
          'target': 2,
          'canPromote': silverReferrals >= 2,
        };
        
      case MemberRank.legend:
        return {
          'currentRank': 'Legend Gold',
          'nextRank': 'Next Level',
          'requirement': 'Complete board to advance level',
          'progress': member.level,
          'target': 7,
          'canPromote': false,
        };
    }
  }
}