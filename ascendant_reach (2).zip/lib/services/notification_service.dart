import 'dart:convert';
import 'package:uuid/uuid.dart';
import 'package:ascendant_reach/models/notification.dart';
import 'package:ascendant_reach/services/storage_service.dart';

class NotificationService {
  static const String _storageKey = 'go_win_notifications';
  static const _uuid = Uuid();

  /// Create a new notification
  static Future<String> createNotification({
    required String memberId,
    required String title,
    required String message,
    required NotificationType type,
    Map<String, dynamic>? data,
  }) async {
    final notification = Notification(
      id: _uuid.v4(),
      memberId: memberId,
      title: title,
      message: message,
      type: type,
      createdAt: DateTime.now(),
      data: data,
    );

    final notifications = await getNotifications(memberId);
    notifications.insert(0, notification);

    await _saveNotifications(notifications);
    
    print('📱 Notification created for member $memberId: $title');
    return notification.id;
  }

  /// Get all notifications for a member
  static Future<List<Notification>> getNotifications(String memberId) async {
    try {
      final allNotifications = await _loadAllNotifications();
      return allNotifications
          .where((n) => n.memberId == memberId)
          .toList()
        ..sort((a, b) => b.createdAt.compareTo(a.createdAt));
    } catch (e) {
      print('❌ Error loading notifications: $e');
      return [];
    }
  }

  /// Get unread notification count for a member
  static Future<int> getUnreadCount(String memberId) async {
    final notifications = await getNotifications(memberId);
    return notifications.where((n) => !n.isRead).length;
  }

  /// Mark a notification as read
  static Future<void> markAsRead(String notificationId) async {
    try {
      final allNotifications = await _loadAllNotifications();
      final index = allNotifications.indexWhere((n) => n.id == notificationId);
      
      if (index != -1) {
        allNotifications[index] = allNotifications[index].copyWith(isRead: true);
        await _saveNotifications(allNotifications);
        print('📖 Notification $notificationId marked as read');
      }
    } catch (e) {
      print('❌ Error marking notification as read: $e');
    }
  }

  /// Mark all notifications as read for a member
  static Future<void> markAllAsRead(String memberId) async {
    try {
      final allNotifications = await _loadAllNotifications();
      bool hasChanges = false;
      
      for (int i = 0; i < allNotifications.length; i++) {
        if (allNotifications[i].memberId == memberId && !allNotifications[i].isRead) {
          allNotifications[i] = allNotifications[i].copyWith(isRead: true);
          hasChanges = true;
        }
      }

      if (hasChanges) {
        await _saveNotifications(allNotifications);
        print('📖 All notifications marked as read for member $memberId');
      }
    } catch (e) {
      print('❌ Error marking all notifications as read: $e');
    }
  }

  /// Delete a notification
  static Future<void> deleteNotification(String notificationId) async {
    try {
      final allNotifications = await _loadAllNotifications();
      allNotifications.removeWhere((n) => n.id == notificationId);
      await _saveNotifications(allNotifications);
      print('🗑️ Notification $notificationId deleted');
    } catch (e) {
      print('❌ Error deleting notification: $e');
    }
  }

  /// Clear all notifications for a member
  static Future<void> clearAllNotifications(String memberId) async {
    try {
      final allNotifications = await _loadAllNotifications();
      allNotifications.removeWhere((n) => n.memberId == memberId);
      await _saveNotifications(allNotifications);
      print('🗑️ All notifications cleared for member $memberId');
    } catch (e) {
      print('❌ Error clearing notifications: $e');
    }
  }

  /// Create welcome notifications for new members
  static Future<void> createWelcomeNotifications(String memberId, String memberName) async {
    await createNotification(
      memberId: memberId,
      title: '🎉 Welcome to GO-WIN International!',
      message: 'Welcome $memberName! You have successfully joined the Golden Winners Circle. Start building your network and earning today!',
      type: NotificationType.welcome,
      data: {
        'action': 'view_dashboard',
        'priority': 'high',
      },
    );

    await createNotification(
      memberId: memberId,
      title: '💡 Getting Started Guide',
      message: 'Complete your profile, make your first deposit, and start referring friends to maximize your earnings in the GO-WIN system.',
      type: NotificationType.general,
      data: {
        'action': 'view_profile',
        'priority': 'medium',
      },
    );
  }

  /// Create board approval notification
  static Future<void> createBoardApprovalNotification(
    String memberId,
    String memberName,
    int level,
    double amount,
  ) async {
    await createNotification(
      memberId: memberId,
      title: '✅ Board Join Request Approved!',
      message: 'Congratulations $memberName! Your board join request for Level $level (\$${amount.toStringAsFixed(2)}) has been approved. You can now access your board and start earning!',
      type: NotificationType.boardApproval,
      data: {
        'level': level,
        'amount': amount,
        'action': 'view_board',
        'priority': 'high',
      },
    );
  }

  /// Create board rejection notification
  static Future<void> createBoardRejectionNotification(
    String memberId,
    String memberName,
    int level,
    double amount,
    String reason,
  ) async {
    await createNotification(
      memberId: memberId,
      title: '❌ Board Join Request Rejected',
      message: 'Sorry $memberName, your board join request for Level $level (\$${amount.toStringAsFixed(2)}) has been rejected. Reason: $reason. Please contact support for assistance.',
      type: NotificationType.boardRejection,
      data: {
        'level': level,
        'amount': amount,
        'reason': reason,
        'action': 'contact_support',
        'priority': 'high',
      },
    );
  }

  /// Create withdrawal approval notification
  static Future<void> createWithdrawalApprovalNotification(
    String memberId,
    String memberName,
    double amount,
    String paymentMethod,
  ) async {
    await createNotification(
      memberId: memberId,
      title: '💰 Withdrawal Approved!',
      message: 'Great news $memberName! Your withdrawal request of \$${amount.toStringAsFixed(2)} has been approved. The funds will be transferred to your $paymentMethod account within 1-3 business days.',
      type: NotificationType.withdrawalApproval,
      data: {
        'amount': amount,
        'paymentMethod': paymentMethod,
        'action': 'view_wallet',
        'priority': 'high',
      },
    );
  }

  /// Create withdrawal rejection notification
  static Future<void> createWithdrawalRejectionNotification(
    String memberId,
    String memberName,
    double amount,
    String reason,
  ) async {
    await createNotification(
      memberId: memberId,
      title: '❌ Withdrawal Request Rejected',
      message: 'Sorry $memberName, your withdrawal request of \$${amount.toStringAsFixed(2)} has been rejected. Reason: $reason. Please contact support for assistance.',
      type: NotificationType.withdrawalRejection,
      data: {
        'amount': amount,
        'reason': reason,
        'action': 'contact_support',
        'priority': 'high',
      },
    );
  }

  /// Create level up notification
  static Future<void> createLevelUpNotification(
    String memberId,
    String memberName,
    int newLevel,
    String newRank,
  ) async {
    await createNotification(
      memberId: memberId,
      title: '🎊 Level Up Achievement!',
      message: 'Congratulations $memberName! You have been promoted to Level $newLevel ($newRank)! Keep building your network to unlock even more rewards.',
      type: NotificationType.levelUp,
      data: {
        'newLevel': newLevel,
        'newRank': newRank,
        'action': 'view_profile',
        'priority': 'high',
      },
    );
  }

  /// Create referral bonus notification
  static Future<void> createReferralBonusNotification(
    String memberId,
    String memberName,
    String referredName,
    double bonus,
  ) async {
    await createNotification(
      memberId: memberId,
      title: '💵 Referral Bonus Earned!',
      message: 'You earned \$${bonus.toStringAsFixed(2)} for referring $referredName to GO-WIN International! Keep sharing to earn more bonuses.',
      type: NotificationType.referralBonus,
      data: {
        'referredName': referredName,
        'bonus': bonus,
        'action': 'view_wallet',
        'priority': 'medium',
      },
    );
  }

  /// Create earnings milestone notification
  static Future<void> createEarningsMilestoneNotification(
    String memberId,
    String memberName,
    double totalEarnings,
    String milestone,
  ) async {
    await createNotification(
      memberId: memberId,
      title: '🎉 Earnings Milestone Reached!',
      message: 'Congratulations $memberName! You have reached \$${totalEarnings.toStringAsFixed(2)} in total earnings! $milestone milestone unlocked!',
      type: NotificationType.general,
      data: {
        'totalEarnings': totalEarnings,
        'milestone': milestone,
        'action': 'view_earnings',
        'priority': 'high',
      },
    );
  }

  /// Create board completion notification
  static Future<void> createBoardCompletionNotification(
    String memberId,
    String memberName,
    int level,
    double commission,
  ) async {
    await createNotification(
      memberId: memberId,
      title: '🏆 Board Completed!',
      message: 'Amazing achievement $memberName! Your Level $level board is complete! You earned \$${commission.toStringAsFixed(2)} commission and can advance to the next level!',
      type: NotificationType.boardApproval,
      data: {
        'level': level,
        'commission': commission,
        'action': 'view_board',
        'priority': 'high',
      },
    );
  }

  /// Create payment method update notification
  static Future<void> createPaymentMethodNotification(
    String memberId,
    String memberName,
    String action,
    String paymentMethod,
  ) async {
    await createNotification(
      memberId: memberId,
      title: '💳 Payment Method Update',
      message: 'Your payment method has been $action: $paymentMethod. You can now use this method for deposits and withdrawals.',
      type: NotificationType.general,
      data: {
        'action': action,
        'paymentMethod': paymentMethod,
        'action_button': 'view_wallet',
        'priority': 'medium',
      },
    );
  }

  /// Send admin notification for user actions
  static Future<void> notifyAdminsOfUserAction(
    String userId,
    String userName,
    String action,
    Map<String, dynamic> actionData,
  ) async {
    final adminEmails = [
      'jaytechpromo@gmail.com',
      'lubejy09@gmail.com',
      'luberissejames60@gmail.com',
      'jamesluberisse30@gmail.com',
    ];
    
    // Get admin member IDs
    final members = StorageService.getMembers();
    final admins = members.where((m) => adminEmails.contains(m.email.toLowerCase())).toList();
    
    for (final admin in admins) {
      await createNotification(
        memberId: admin.id,
        title: '👥 User Activity: $action',
        message: '$userName has performed: $action. Review required.',
        type: NotificationType.general,
        data: {
          'userId': userId,
          'userName': userName,
          'action': action,
          'actionData': actionData,
          'requiresReview': true,
          'priority': 'high',
        },
      );
    }
  }

  /// Private methods
  static Future<List<Notification>> _loadAllNotifications() async {
    try {
      final prefs = StorageService.prefs;
      final notificationsJson = prefs.getString(_storageKey) ?? '[]';
      final List<dynamic> notificationsList = json.decode(notificationsJson);
      
      return notificationsList
          .map((json) => Notification.fromJson(json))
          .toList();
    } catch (e) {
      print('❌ Error loading all notifications: $e');
      return [];
    }
  }

  static Future<void> _saveNotifications(List<Notification> notifications) async {
    try {
      final prefs = StorageService.prefs;
      final notificationsJson = json.encode(
        notifications.map((n) => n.toJson()).toList(),
      );
      await prefs.setString(_storageKey, notificationsJson);
    } catch (e) {
      print('❌ Error saving notifications: $e');
    }
  }
}