import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:ascendant_reach/models/member.dart';
import 'package:ascendant_reach/models/board.dart';
import 'package:ascendant_reach/models/transaction.dart';
import 'package:ascendant_reach/models/course.dart';
import 'package:ascendant_reach/models/product.dart';
import 'package:ascendant_reach/models/board_join_request.dart';
import 'package:ascendant_reach/models/withdrawal_request.dart';
import 'package:ascendant_reach/models/pending_transaction.dart';

class StorageService {
  static const String _currentMemberKey = 'current_member';
  static const String _membersKey = 'members';
  static const String _boardsKey = 'boards';
  static const String _transactionsKey = 'transactions';
  static const String _coursesKey = 'courses';
  static const String _productsKey = 'products';
  static const String _boardJoinRequestsKey = 'board_join_requests';
  static const String _withdrawalRequestsKey = 'withdrawal_requests';
  static const String _pendingTransactionsKey = 'pending_transactions';
  static const String _progressReportsKey = 'progress_reports';
  static const String _userActivityKey = 'user_activity';
  static const String _systemSettingsKey = 'system_settings';
  static const String _paymentMethodsKey = 'payment_methods';

  static SharedPreferences? _prefs;

  static Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
  }

  static SharedPreferences get prefs {
    if (_prefs == null) throw Exception('StorageService not initialized');
    return _prefs!;
  }

  // General preferences
  static Future<void> savePreference(String key, String value) async {
    await prefs.setString(key, value);
  }

  static String? getPreference(String key) {
    return prefs.getString(key);
  }

  // Current Member
  static Future<void> saveCurrentMember(Member member) async {
    await prefs.setString(_currentMemberKey, jsonEncode(member.toJson()));
  }

  static Member? getCurrentMember() {
    final memberJson = prefs.getString(_currentMemberKey);
    if (memberJson == null) return null;
    return Member.fromJson(jsonDecode(memberJson));
  }

  static Future<void> clearCurrentMember() async {
    await prefs.remove(_currentMemberKey);
  }

  // Members
  static Future<void> saveMembers(List<Member> members) async {
    final membersJson = members.map((m) => m.toJson()).toList();
    await prefs.setString(_membersKey, jsonEncode(membersJson));
  }

  static List<Member> getMembers() {
    final membersJson = prefs.getString(_membersKey);
    if (membersJson == null) return [];
    final List<dynamic> membersList = jsonDecode(membersJson);
    return membersList.map((json) => Member.fromJson(json)).toList();
  }

  // Boards
  static Future<void> saveBoards(List<MLMBoard> boards) async {
    final boardsJson = boards.map((b) => b.toJson()).toList();
    await prefs.setString(_boardsKey, jsonEncode(boardsJson));
  }

  static List<MLMBoard> getBoards() {
    final boardsJson = prefs.getString(_boardsKey);
    if (boardsJson == null) return [];
    final List<dynamic> boardsList = jsonDecode(boardsJson);
    return boardsList.map((json) => MLMBoard.fromJson(json)).toList();
  }

  // Transactions
  static Future<void> saveTransactions(List<Transaction> transactions) async {
    final transactionsJson = transactions.map((t) => t.toJson()).toList();
    await prefs.setString(_transactionsKey, jsonEncode(transactionsJson));
  }

  static List<Transaction> getTransactions() {
    final transactionsJson = prefs.getString(_transactionsKey);
    if (transactionsJson == null) return [];
    final List<dynamic> transactionsList = jsonDecode(transactionsJson);
    return transactionsList.map((json) => Transaction.fromJson(json)).toList();
  }

  // Courses
  static Future<void> saveCourses(List<Course> courses) async {
    final coursesJson = courses.map((c) => c.toJson()).toList();
    await prefs.setString(_coursesKey, jsonEncode(coursesJson));
  }

  static List<Course> getCourses() {
    final coursesJson = prefs.getString(_coursesKey);
    if (coursesJson == null) return [];
    final List<dynamic> coursesList = jsonDecode(coursesJson);
    return coursesList.map((json) => Course.fromJson(json)).toList();
  }

  // Products
  static Future<void> saveProducts(List<Product> products) async {
    final productsJson = products.map((p) => p.toJson()).toList();
    await prefs.setString(_productsKey, jsonEncode(productsJson));
  }

  static List<Product> getProducts() {
    final productsJson = prefs.getString(_productsKey);
    if (productsJson == null) return [];
    final List<dynamic> productsList = jsonDecode(productsJson);
    return productsList.map((json) => Product.fromJson(json)).toList();
  }

  // Board Join Requests
  static Future<void> saveBoardJoinRequests(List<BoardJoinRequest> requests) async {
    final requestsJson = requests.map((r) => r.toJson()).toList();
    await prefs.setString(_boardJoinRequestsKey, jsonEncode(requestsJson));
  }

  static List<BoardJoinRequest> getBoardJoinRequests() {
    final requestsJson = prefs.getString(_boardJoinRequestsKey);
    if (requestsJson == null) return [];
    final List<dynamic> requestsList = jsonDecode(requestsJson);
    return requestsList.map((json) => BoardJoinRequest.fromJson(json)).toList();
  }

  // Withdrawal Requests
  static Future<void> saveWithdrawalRequests(List<WithdrawalRequest> requests) async {
    final requestsJson = requests.map((r) => r.toJson()).toList();
    await prefs.setString(_withdrawalRequestsKey, jsonEncode(requestsJson));
  }

  static List<WithdrawalRequest> getWithdrawalRequests() {
    final requestsJson = prefs.getString(_withdrawalRequestsKey);
    if (requestsJson == null) return [];
    final List<dynamic> requestsList = jsonDecode(requestsJson);
    return requestsList.map((json) => WithdrawalRequest.fromJson(json)).toList();
  }

  // Pending Transactions
  static Future<void> savePendingTransactions(List<PendingTransaction> transactions) async {
    final transactionsJson = transactions.map((t) => t.toJson()).toList();
    await prefs.setString(_pendingTransactionsKey, jsonEncode(transactionsJson));
  }

  static List<PendingTransaction> getPendingTransactions() {
    final transactionsJson = prefs.getString(_pendingTransactionsKey);
    if (transactionsJson == null) return [];
    final List<dynamic> transactionsList = jsonDecode(transactionsJson);
    return transactionsList.map((json) => PendingTransaction.fromJson(json)).toList();
  }

  // Progress Reports for Admin Tracking
  static Future<void> saveProgressReports(List<Map<String, dynamic>> reports) async {
    await prefs.setString(_progressReportsKey, jsonEncode(reports));
  }

  static List<Map<String, dynamic>>? getProgressReports() {
    final reportsJson = prefs.getString(_progressReportsKey);
    if (reportsJson == null) return [];
    final List<dynamic> reportsList = jsonDecode(reportsJson);
    return reportsList.cast<Map<String, dynamic>>();
  }

  // User Activity Tracking
  static Future<void> logUserActivity(String memberId, String action, Map<String, dynamic> data) async {
    try {
      final activities = getUserActivity() ?? [];
      final activity = {
        'id': DateTime.now().millisecondsSinceEpoch.toString(),
        'memberId': memberId,
        'action': action,
        'data': data,
        'timestamp': DateTime.now().toIso8601String(),
        'ipAddress': '127.0.0.1', // Mock IP for demo
      };
      
      activities.insert(0, activity);
      
      // Keep only last 1000 activities to manage storage
      if (activities.length > 1000) {
        activities.removeRange(1000, activities.length);
      }
      
      await prefs.setString(_userActivityKey, jsonEncode(activities));
    } catch (e) {
      print('❌ Failed to log user activity: $e');
    }
  }

  static List<Map<String, dynamic>>? getUserActivity() {
    final activityJson = prefs.getString(_userActivityKey);
    if (activityJson == null) return [];
    final List<dynamic> activityList = jsonDecode(activityJson);
    return activityList.cast<Map<String, dynamic>>();
  }

  static List<Map<String, dynamic>> getMemberActivity(String memberId) {
    final allActivity = getUserActivity() ?? [];
    return allActivity.where((activity) => activity['memberId'] == memberId).toList();
  }

  // System Settings
  static Future<void> saveSystemSettings(Map<String, dynamic> settings) async {
    await prefs.setString(_systemSettingsKey, jsonEncode(settings));
  }

  static Map<String, dynamic> getSystemSettings() {
    final settingsJson = prefs.getString(_systemSettingsKey);
    if (settingsJson == null) {
      // Default settings
      return {
        'minDepositAmount': 1.0,
        'minWithdrawalAmount': 5.0,
        'maxWithdrawalAmount': 100.0,
        'withdrawalFrequency': 'weekly', // daily, weekly, monthly
        'commissionRates': {
          'level1': 100, // 100%
          'level2': 75,  // 75%
          'level3': 50,  // 50%
        },
        'levelUpgradeCosts': {
          '2': 5.0,
          '3': 10.0,
          '4': 20.0,
          '5': 50.0,
          '6': 100.0,
          '7': 200.0,
        },
        'paymentMethods': ['PayPal', 'Bank Transfer', 'Credit Card', 'Credit Livegood', 'Cash'],
        'autoApprovalEnabled': false,
        'maintenanceMode': false,
      };
    }
    return jsonDecode(settingsJson);
  }

  // Payment Methods Management
  static Future<void> savePaymentMethods(List<String> methods) async {
    await prefs.setString(_paymentMethodsKey, jsonEncode(methods));
  }

  static List<String> getPaymentMethods() {
    final settings = getSystemSettings();
    return List<String>.from(settings['paymentMethods'] ?? [
      'PayPal', 'Bank Transfer', 'Credit Card', 'Credit Livegood', 'Cash'
    ]);
  }

  // Enhanced User Data Persistence
  static Future<void> saveUserDataSnapshot(String memberId) async {
    try {
      final members = getMembers();
      final member = members.firstWhere((m) => m.id == memberId, orElse: () => Member.empty());
      
      if (member.id.isNotEmpty) {
        final snapshot = {
          'memberId': memberId,
          'memberData': member.toJson(),
          'timestamp': DateTime.now().toIso8601String(),
          'version': '1.0',
        };
        
        await prefs.setString('snapshot_$memberId', jsonEncode(snapshot));
        await logUserActivity(memberId, 'data_snapshot', {'action': 'saved'});
      }
    } catch (e) {
      print('❌ Failed to save user data snapshot: $e');
    }
  }

  static Map<String, dynamic>? getUserDataSnapshot(String memberId) {
    final snapshotJson = prefs.getString('snapshot_$memberId');
    if (snapshotJson == null) return null;
    return jsonDecode(snapshotJson);
  }

  // Clear all data (for testing or reset)
  static Future<void> clearAllData() async {
    await prefs.clear();
  }

  // Backup and restore functionality
  static Map<String, dynamic> createFullBackup() {
    return {
      'members': getMembers().map((m) => m.toJson()).toList(),
      'boards': getBoards().map((b) => b.toJson()).toList(),
      'transactions': getTransactions().map((t) => t.toJson()).toList(),
      'courses': getCourses().map((c) => c.toJson()).toList(),
      'products': getProducts().map((p) => p.toJson()).toList(),
      'boardJoinRequests': getBoardJoinRequests().map((r) => r.toJson()).toList(),
      'withdrawalRequests': getWithdrawalRequests().map((r) => r.toJson()).toList(),
      'pendingTransactions': getPendingTransactions().map((t) => t.toJson()).toList(),
      'progressReports': getProgressReports(),
      'userActivity': getUserActivity(),
      'systemSettings': getSystemSettings(),
      'backupDate': DateTime.now().toIso8601String(),
      'version': '1.0',
    };
  }

  static Future<bool> restoreFromBackup(Map<String, dynamic> backup) async {
    try {
      // Restore members
      if (backup['members'] != null) {
        final members = (backup['members'] as List).map((json) => Member.fromJson(json)).toList();
        await saveMembers(members);
      }
      
      // Restore other data...
      // Add more restore logic as needed
      
      return true;
    } catch (e) {
      print('❌ Failed to restore from backup: $e');
      return false;
    }
  }
}