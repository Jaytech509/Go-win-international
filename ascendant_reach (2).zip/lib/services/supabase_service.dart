import 'package:ascendant_reach/supabase/supabase_config.dart';
import 'package:ascendant_reach/models/member.dart';
import 'package:ascendant_reach/models/board.dart';
import 'package:ascendant_reach/models/transaction.dart';
import 'package:ascendant_reach/models/withdrawal_request.dart';
import 'package:ascendant_reach/models/board_join_request.dart';
import 'package:ascendant_reach/models/course.dart';
import 'package:ascendant_reach/models/product.dart';
import 'package:uuid/uuid.dart';

/// GO-WIN INTERNATIONAL Supabase Service
/// Handles all database operations for the MLM platform
class GoWinSupabaseService {
  static const _uuid = Uuid();

  // ===================
  // Authentication
  // ===================
  
  /// Sign up a new user
  static Future<Map<String, dynamic>?> signUp({
    required String email,
    required String password,
    required String name,
    required String phone,
    String? referralCode,
  }) async {
    try {
      // Generate unique referral code for new user
      final userReferralCode = _generateReferralCode();
      
      // Find referrer if referral code provided
      String? referrerId;
      if (referralCode != null && referralCode.isNotEmpty) {
        final referrer = await SupabaseService.selectSingle(
          'users',
          filters: {'referral_code': referralCode},
        );
        referrerId = referrer?['id'];
      }
      
      final response = await SupabaseAuth.signUp(
        email: email,
        password: password,
        userData: {
          'name': name,
          'phone': phone,
          'referral_code': userReferralCode,
          'referred_by': referrerId,
          'is_admin': ['jaytechpromo@gmail.com', 'lubejy09@gmail.com'].contains(email),
        },
      );

      if (response.user != null) {
        // Create wallet balance for new user
        await SupabaseService.insert('wallet_balances', {
          'user_id': response.user!.id,
          'main_balance': 0,
          'earning_balance': 0,
          'points': 0,
        });
      }

      return {
        'user': response.user?.toJson(),
        'session': response.session?.toJson(),
      };
    } catch (e) {
      throw Exception('Failed to sign up: $e');
    }
  }

  /// Sign in user
  static Future<Map<String, dynamic>?> signIn({
    required String email,
    required String password,
  }) async {
    try {
      final response = await SupabaseAuth.signIn(
        email: email,
        password: password,
      );

      return {
        'user': response.user?.toJson(),
        'session': response.session?.toJson(),
      };
    } catch (e) {
      throw Exception('Failed to sign in: $e');
    }
  }

  /// Sign out user
  static Future<void> signOut() async {
    await SupabaseAuth.signOut();
  }

  // ===================
  // User Management
  // ===================
  
  /// Get user profile
  static Future<Member?> getUserProfile(String userId) async {
    try {
      final userData = await SupabaseService.selectSingle(
        'users',
        filters: {'id': userId},
      );
      
      if (userData == null) return null;
      
      return Member.fromJson(userData);
    } catch (e) {
      throw Exception('Failed to get user profile: $e');
    }
  }

  /// Update user profile
  static Future<void> updateUserProfile(String userId, Map<String, dynamic> updates) async {
    try {
      await SupabaseService.update(
        'users',
        updates,
        filters: {'id': userId},
      );
    } catch (e) {
      throw Exception('Failed to update user profile: $e');
    }
  }

  /// Get user's wallet balance
  static Future<Map<String, dynamic>?> getWalletBalance(String userId) async {
    try {
      return await SupabaseService.selectSingle(
        'wallet_balances',
        filters: {'user_id': userId},
      );
    } catch (e) {
      throw Exception('Failed to get wallet balance: $e');
    }
  }

  /// Update wallet balance
  static Future<void> updateWalletBalance(String userId, Map<String, dynamic> updates) async {
    try {
      await SupabaseService.update(
        'wallet_balances',
        updates,
        filters: {'user_id': userId},
      );
    } catch (e) {
      throw Exception('Failed to update wallet balance: $e');
    }
  }

  // ===================
  // Board Management
  // ===================
  
  /// Get user's current board
  static Future<MLMBoard?> getUserBoard(String userId) async {
    try {
      final boardData = await SupabaseService.selectSingle(
        'boards',
        filters: {'legend_gold_id': userId},
      );
      
      if (boardData == null) return null;
      
      // Get board members
      final membersData = await SupabaseService.select(
        'board_members',
        filters: {'board_id': boardData['id']},
        orderBy: 'position',
      );

      // Convert to the expected format
      final positions = List.generate(14, (index) {
        Map<String, dynamic>? memberData;
        try {
          memberData = membersData.firstWhere(
            (member) => member['position'] == index,
          );
        } catch (e) {
          memberData = null;
        }
        
        return BoardPosition(
          position: index,
          memberId: memberData?['user_id'],
          memberName: null, // Will need to fetch user name separately if needed
        );
      });

      return MLMBoard(
        id: boardData['id'],
        level: boardData['level'],
        positions: positions,
        isComplete: boardData['is_complete'] ?? false,
        createdAt: DateTime.parse(boardData['created_at']),
        legendMemberId: boardData['legend_gold_id'],
      );
    } catch (e) {
      throw Exception('Failed to get user board: $e');
    }
  }

  /// Create board join request
  static Future<void> createBoardJoinRequest({
    required String userId,
    required String boardId,
    required double amount,
    required String paymentMethod,
    String? accountIdNumber,
    String? accountName,
  }) async {
    try {
      await SupabaseService.insert('board_join_requests', {
        'id': _uuid.v4(),
        'user_id': userId,
        'board_id': boardId,
        'amount': amount,
        'payment_method': paymentMethod,
        'account_id_number': accountIdNumber,
        'account_name': accountName,
        'status': 'pending',
      });
    } catch (e) {
      throw Exception('Failed to create board join request: $e');
    }
  }

  /// Get pending board join requests (admin)
  static Future<List<BoardJoinRequest>> getPendingBoardJoinRequests() async {
    try {
      final requestsData = await SupabaseService.select(
        'board_join_requests',
        filters: {'status': 'pending'},
        orderBy: 'created_at',
        ascending: false,
      );

      return requestsData.map((data) => BoardJoinRequest.fromJson(data)).toList();
    } catch (e) {
      throw Exception('Failed to get pending board join requests: $e');
    }
  }

  /// Approve board join request
  static Future<void> approveBoardJoinRequest(String requestId, String adminId) async {
    try {
      await SupabaseService.update(
        'board_join_requests',
        {
          'status': 'approved',
          'approved_at': DateTime.now().toIso8601String(),
          'approved_by': adminId,
        },
        filters: {'id': requestId},
      );
      
      // Additional logic for adding user to board can be implemented here
    } catch (e) {
      throw Exception('Failed to approve board join request: $e');
    }
  }

  // ===================
  // Transaction Management
  // ===================
  
  /// Create transaction
  static Future<void> createTransaction({
    required String userId,
    required String type,
    required double amount,
    String? paymentMethod,
    String? accountIdNumber,
    String? accountName,
    String? description,
    String? fromUserId,
    String? toUserId,
  }) async {
    try {
      await SupabaseService.insert('transactions', {
        'id': _uuid.v4(),
        'user_id': userId,
        'type': type,
        'amount': amount,
        'payment_method': paymentMethod,
        'account_id_number': accountIdNumber,
        'account_name': accountName,
        'description': description,
        'from_user_id': fromUserId,
        'to_user_id': toUserId,
        'status': 'pending',
      });
    } catch (e) {
      throw Exception('Failed to create transaction: $e');
    }
  }

  /// Get user transactions
  static Future<List<Transaction>> getUserTransactions(String userId) async {
    try {
      final transactionsData = await SupabaseService.select(
        'transactions',
        filters: {'user_id': userId},
        orderBy: 'created_at',
        ascending: false,
      );

      return transactionsData.map((data) => Transaction.fromJson(data)).toList();
    } catch (e) {
      throw Exception('Failed to get user transactions: $e');
    }
  }

  // ===================
  // Withdrawal Management
  // ===================
  
  /// Create withdrawal request
  static Future<void> createWithdrawalRequest({
    required String userId,
    required double amount,
    required String paymentMethod,
    required String accountIdNumber,
    required String accountName,
  }) async {
    try {
      await SupabaseService.insert('withdrawal_requests', {
        'id': _uuid.v4(),
        'user_id': userId,
        'amount': amount,
        'payment_method': paymentMethod,
        'account_id_number': accountIdNumber,
        'account_name': accountName,
        'status': 'pending',
      });
    } catch (e) {
      throw Exception('Failed to create withdrawal request: $e');
    }
  }

  /// Get pending withdrawal requests (admin)
  static Future<List<WithdrawalRequest>> getPendingWithdrawalRequests() async {
    try {
      final requestsData = await SupabaseService.select(
        'withdrawal_requests',
        filters: {'status': 'pending'},
        orderBy: 'created_at',
        ascending: false,
      );

      return requestsData.map((data) => WithdrawalRequest.fromJson(data)).toList();
    } catch (e) {
      throw Exception('Failed to get pending withdrawal requests: $e');
    }
  }

  /// Approve withdrawal request
  static Future<void> approveWithdrawalRequest(String requestId, String adminId) async {
    try {
      await SupabaseService.update(
        'withdrawal_requests',
        {
          'status': 'approved',
          'approved_at': DateTime.now().toIso8601String(),
          'approved_by': adminId,
        },
        filters: {'id': requestId},
      );
    } catch (e) {
      throw Exception('Failed to approve withdrawal request: $e');
    }
  }

  // ===================
  // Courses Management
  // ===================
  
  /// Get all courses
  static Future<List<Course>> getCourses() async {
    try {
      final coursesData = await SupabaseService.select(
        'courses',
        filters: {'is_active': true},
        orderBy: 'created_at',
        ascending: false,
      );

      return coursesData.map((data) => Course.fromJson(data)).toList();
    } catch (e) {
      throw Exception('Failed to get courses: $e');
    }
  }

  // ===================
  // Products Management
  // ===================
  
  /// Get all products
  static Future<List<Product>> getProducts() async {
    try {
      final productsData = await SupabaseService.select(
        'products',
        filters: {'is_active': true},
        orderBy: 'created_at',
        ascending: false,
      );

      return productsData.map((data) => Product.fromJson(data)).toList();
    } catch (e) {
      throw Exception('Failed to get products: $e');
    }
  }

  // ===================
  // Referral System
  // ===================
  
  /// Get user's referrals
  static Future<List<Member>> getUserReferrals(String userId) async {
    try {
      final referralsData = await SupabaseService.select(
        'users',
        filters: {'referred_by': userId},
        orderBy: 'created_at',
        ascending: false,
      );

      return referralsData.map((data) => Member.fromJson(data)).toList();
    } catch (e) {
      throw Exception('Failed to get user referrals: $e');
    }
  }

  /// Calculate and distribute referral earnings
  static Future<void> distributeReferralEarnings({
    required String referredUserId,
    required double amount,
    required String earnedFrom,
  }) async {
    try {
      final referredUser = await getUserProfile(referredUserId);
      if (referredUser == null) return;

      String? currentReferrerId = referredUser.referredBy;
      int level = 1;
      
      while (currentReferrerId != null && level <= 3) {
        double percentage;
        switch (level) {
          case 1: percentage = 100; break;
          case 2: percentage = 75; break;
          case 3: percentage = 50; break;
          default: percentage = 0;
        }

        if (percentage > 0) {
          final earningAmount = amount * (percentage / 100);
          
          // Record referral earning
          await SupabaseService.insert('referral_earnings', {
            'id': _uuid.v4(),
            'user_id': currentReferrerId,
            'referred_user_id': referredUserId,
            'amount': earningAmount,
            'percentage': percentage.toInt(),
            'level': level,
            'earned_from': earnedFrom,
          });

          // Update earning balance
          final currentBalance = await getWalletBalance(currentReferrerId);
          if (currentBalance != null) {
            await updateWalletBalance(currentReferrerId, {
              'earning_balance': (currentBalance['earning_balance'] ?? 0) + earningAmount,
            });
          }
        }

        // Get next level referrer
        final currentReferrer = await getUserProfile(currentReferrerId);
        currentReferrerId = currentReferrer?.referredBy;
        level++;
      }
    } catch (e) {
      throw Exception('Failed to distribute referral earnings: $e');
    }
  }

  // ===================
  // Level Upgrade System
  // ===================
  
  /// Create level upgrade payment
  static Future<void> createLevelUpgradePayment({
    required String userId,
    required int fromLevel,
    required int toLevel,
    required double amount,
  }) async {
    try {
      await SupabaseService.insert('level_upgrade_payments', {
        'id': _uuid.v4(),
        'user_id': userId,
        'from_level': fromLevel,
        'to_level': toLevel,
        'amount': amount,
        'status': 'pending',
      });
    } catch (e) {
      throw Exception('Failed to create level upgrade payment: $e');
    }
  }

  // ===================
  // Utility Methods
  // ===================
  
  /// Generate unique referral code
  static String _generateReferralCode() {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    return List.generate(8, (index) => chars[(DateTime.now().millisecondsSinceEpoch + index) % chars.length]).join();
  }

  /// Get current user
  static String? get currentUserId => SupabaseAuth.currentUser?.id;
  
  /// Check if user is authenticated
  static bool get isAuthenticated => SupabaseAuth.isAuthenticated;
}