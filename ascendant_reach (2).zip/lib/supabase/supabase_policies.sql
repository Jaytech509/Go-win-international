-- GO-WIN INTERNATIONAL Security Policies
-- Enable row-level security and create policies for all tables

-- Enable RLS on all tables
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE boards ENABLE ROW LEVEL SECURITY;
ALTER TABLE board_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE board_join_requests ENABLE ROW LEVEL SECURITY;
ALTER TABLE transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE withdrawal_requests ENABLE ROW LEVEL SECURITY;
ALTER TABLE wallet_balances ENABLE ROW LEVEL SECURITY;
ALTER TABLE referral_earnings ENABLE ROW LEVEL SECURITY;
ALTER TABLE courses ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_course_progress ENABLE ROW LEVEL SECURITY;
ALTER TABLE products ENABLE ROW LEVEL SECURITY;
ALTER TABLE product_purchases ENABLE ROW LEVEL SECURITY;
ALTER TABLE level_upgrade_payments ENABLE ROW LEVEL SECURITY;

-- Users table policies
CREATE POLICY "Users can view all users" ON users
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "Users can insert their own profile" ON users
  FOR INSERT TO authenticated WITH CHECK (true);

CREATE POLICY "Users can update their own profile" ON users
  FOR UPDATE TO authenticated 
  USING (auth.uid() = id OR EXISTS(SELECT 1 FROM users WHERE id = auth.uid() AND is_admin = true))
  WITH CHECK (true);

CREATE POLICY "Users can delete their own profile" ON users
  FOR DELETE TO authenticated USING (auth.uid() = id);

-- Boards table policies
CREATE POLICY "All authenticated users can view boards" ON boards
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "Authenticated users can create boards" ON boards
  FOR INSERT TO authenticated WITH CHECK (true);

CREATE POLICY "Board owners and admins can update boards" ON boards
  FOR UPDATE TO authenticated 
  USING (legend_gold_id = auth.uid() OR EXISTS(SELECT 1 FROM users WHERE id = auth.uid() AND is_admin = true))
  WITH CHECK (true);

CREATE POLICY "Admins can delete boards" ON boards
  FOR DELETE TO authenticated USING (EXISTS(SELECT 1 FROM users WHERE id = auth.uid() AND is_admin = true));

-- Board members table policies
CREATE POLICY "All authenticated users can view board members" ON board_members
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "Authenticated users can join boards" ON board_members
  FOR INSERT TO authenticated WITH CHECK (true);

CREATE POLICY "Board owners and admins can update board members" ON board_members
  FOR UPDATE TO authenticated 
  USING (user_id = auth.uid() OR EXISTS(SELECT 1 FROM boards b WHERE b.id = board_id AND b.legend_gold_id = auth.uid()) OR EXISTS(SELECT 1 FROM users WHERE id = auth.uid() AND is_admin = true))
  WITH CHECK (true);

CREATE POLICY "Board owners and admins can remove board members" ON board_members
  FOR DELETE TO authenticated USING (user_id = auth.uid() OR EXISTS(SELECT 1 FROM boards b WHERE b.id = board_id AND b.legend_gold_id = auth.uid()) OR EXISTS(SELECT 1 FROM users WHERE id = auth.uid() AND is_admin = true));

-- Board join requests table policies
CREATE POLICY "Users can view their own requests and admins can view all" ON board_join_requests
  FOR SELECT TO authenticated USING (user_id = auth.uid() OR EXISTS(SELECT 1 FROM users WHERE id = auth.uid() AND is_admin = true));

CREATE POLICY "Authenticated users can create join requests" ON board_join_requests
  FOR INSERT TO authenticated WITH CHECK (true);

CREATE POLICY "Admins can update join requests" ON board_join_requests
  FOR UPDATE TO authenticated 
  USING (EXISTS(SELECT 1 FROM users WHERE id = auth.uid() AND is_admin = true))
  WITH CHECK (true);

CREATE POLICY "Users can delete their own requests" ON board_join_requests
  FOR DELETE TO authenticated USING (user_id = auth.uid());

-- Transactions table policies
CREATE POLICY "Users can view their own transactions and admins can view all" ON transactions
  FOR SELECT TO authenticated USING (user_id = auth.uid() OR from_user_id = auth.uid() OR to_user_id = auth.uid() OR EXISTS(SELECT 1 FROM users WHERE id = auth.uid() AND is_admin = true));

CREATE POLICY "Authenticated users can create transactions" ON transactions
  FOR INSERT TO authenticated WITH CHECK (true);

CREATE POLICY "Admins can update transactions" ON transactions
  FOR UPDATE TO authenticated 
  USING (EXISTS(SELECT 1 FROM users WHERE id = auth.uid() AND is_admin = true))
  WITH CHECK (true);

CREATE POLICY "Admins can delete transactions" ON transactions
  FOR DELETE TO authenticated USING (EXISTS(SELECT 1 FROM users WHERE id = auth.uid() AND is_admin = true));

-- Withdrawal requests table policies
CREATE POLICY "Users can view their own withdrawal requests and admins can view all" ON withdrawal_requests
  FOR SELECT TO authenticated USING (user_id = auth.uid() OR EXISTS(SELECT 1 FROM users WHERE id = auth.uid() AND is_admin = true));

CREATE POLICY "Authenticated users can create withdrawal requests" ON withdrawal_requests
  FOR INSERT TO authenticated WITH CHECK (true);

CREATE POLICY "Admins can update withdrawal requests" ON withdrawal_requests
  FOR UPDATE TO authenticated 
  USING (EXISTS(SELECT 1 FROM users WHERE id = auth.uid() AND is_admin = true))
  WITH CHECK (true);

CREATE POLICY "Users can delete their own withdrawal requests" ON withdrawal_requests
  FOR DELETE TO authenticated USING (user_id = auth.uid());

-- Wallet balances table policies
CREATE POLICY "Users can view their own wallet balance and admins can view all" ON wallet_balances
  FOR SELECT TO authenticated USING (user_id = auth.uid() OR EXISTS(SELECT 1 FROM users WHERE id = auth.uid() AND is_admin = true));

CREATE POLICY "Authenticated users can create wallet balance" ON wallet_balances
  FOR INSERT TO authenticated WITH CHECK (true);

CREATE POLICY "Users can update their own wallet balance" ON wallet_balances
  FOR UPDATE TO authenticated 
  USING (user_id = auth.uid() OR EXISTS(SELECT 1 FROM users WHERE id = auth.uid() AND is_admin = true))
  WITH CHECK (true);

CREATE POLICY "Admins can delete wallet balances" ON wallet_balances
  FOR DELETE TO authenticated USING (EXISTS(SELECT 1 FROM users WHERE id = auth.uid() AND is_admin = true));

-- Referral earnings table policies
CREATE POLICY "Users can view their own referral earnings and admins can view all" ON referral_earnings
  FOR SELECT TO authenticated USING (user_id = auth.uid() OR EXISTS(SELECT 1 FROM users WHERE id = auth.uid() AND is_admin = true));

CREATE POLICY "Authenticated users can create referral earnings" ON referral_earnings
  FOR INSERT TO authenticated WITH CHECK (true);

CREATE POLICY "Admins can update referral earnings" ON referral_earnings
  FOR UPDATE TO authenticated 
  USING (EXISTS(SELECT 1 FROM users WHERE id = auth.uid() AND is_admin = true))
  WITH CHECK (true);

CREATE POLICY "Admins can delete referral earnings" ON referral_earnings
  FOR DELETE TO authenticated USING (EXISTS(SELECT 1 FROM users WHERE id = auth.uid() AND is_admin = true));

-- Courses table policies
CREATE POLICY "All authenticated users can view courses" ON courses
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "Admins can create courses" ON courses
  FOR INSERT TO authenticated WITH CHECK (EXISTS(SELECT 1 FROM users WHERE id = auth.uid() AND is_admin = true));

CREATE POLICY "Admins can update courses" ON courses
  FOR UPDATE TO authenticated 
  USING (EXISTS(SELECT 1 FROM users WHERE id = auth.uid() AND is_admin = true))
  WITH CHECK (true);

CREATE POLICY "Admins can delete courses" ON courses
  FOR DELETE TO authenticated USING (EXISTS(SELECT 1 FROM users WHERE id = auth.uid() AND is_admin = true));

-- User course progress table policies
CREATE POLICY "Users can view their own course progress and admins can view all" ON user_course_progress
  FOR SELECT TO authenticated USING (user_id = auth.uid() OR EXISTS(SELECT 1 FROM users WHERE id = auth.uid() AND is_admin = true));

CREATE POLICY "Authenticated users can create course progress" ON user_course_progress
  FOR INSERT TO authenticated WITH CHECK (true);

CREATE POLICY "Users can update their own course progress" ON user_course_progress
  FOR UPDATE TO authenticated 
  USING (user_id = auth.uid())
  WITH CHECK (true);

CREATE POLICY "Users can delete their own course progress" ON user_course_progress
  FOR DELETE TO authenticated USING (user_id = auth.uid());

-- Products table policies
CREATE POLICY "All authenticated users can view products" ON products
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "Admins can create products" ON products
  FOR INSERT TO authenticated WITH CHECK (EXISTS(SELECT 1 FROM users WHERE id = auth.uid() AND is_admin = true));

CREATE POLICY "Admins can update products" ON products
  FOR UPDATE TO authenticated 
  USING (EXISTS(SELECT 1 FROM users WHERE id = auth.uid() AND is_admin = true))
  WITH CHECK (true);

CREATE POLICY "Admins can delete products" ON products
  FOR DELETE TO authenticated USING (EXISTS(SELECT 1 FROM users WHERE id = auth.uid() AND is_admin = true));

-- Product purchases table policies
CREATE POLICY "Users can view their own purchases and admins can view all" ON product_purchases
  FOR SELECT TO authenticated USING (user_id = auth.uid() OR EXISTS(SELECT 1 FROM users WHERE id = auth.uid() AND is_admin = true));

CREATE POLICY "Authenticated users can create purchases" ON product_purchases
  FOR INSERT TO authenticated WITH CHECK (true);

CREATE POLICY "Users can update their own purchases" ON product_purchases
  FOR UPDATE TO authenticated 
  USING (user_id = auth.uid() OR EXISTS(SELECT 1 FROM users WHERE id = auth.uid() AND is_admin = true))
  WITH CHECK (true);

CREATE POLICY "Users can delete their own purchases" ON product_purchases
  FOR DELETE TO authenticated USING (user_id = auth.uid());

-- Level upgrade payments table policies
CREATE POLICY "Users can view their own upgrade payments and admins can view all" ON level_upgrade_payments
  FOR SELECT TO authenticated USING (user_id = auth.uid() OR EXISTS(SELECT 1 FROM users WHERE id = auth.uid() AND is_admin = true));

CREATE POLICY "Authenticated users can create upgrade payments" ON level_upgrade_payments
  FOR INSERT TO authenticated WITH CHECK (true);

CREATE POLICY "Admins can update upgrade payments" ON level_upgrade_payments
  FOR UPDATE TO authenticated 
  USING (EXISTS(SELECT 1 FROM users WHERE id = auth.uid() AND is_admin = true))
  WITH CHECK (true);

CREATE POLICY "Users can delete their own upgrade payments" ON level_upgrade_payments
  FOR DELETE TO authenticated USING (user_id = auth.uid());