-- Sample Data for GO-WIN INTERNATIONAL Database

-- Helper function to insert users into auth.users
CREATE OR REPLACE FUNCTION insert_user_to_auth(email TEXT, password TEXT)
RETURNS UUID AS $$
DECLARE
    user_id UUID;
BEGIN
    INSERT INTO auth.users (instance_id, id, aud, role, email, encrypted_password, email_confirmed_at, created_at, updated_at)
    VALUES (
        '00000000-0000-0000-0000-000000000000',
        gen_random_uuid(),
        'authenticated',
        'authenticated',
        email,
        crypt(password, gen_salt('bf')),
        NOW(),
        NOW(),
        NOW()
    )
    RETURNING id INTO user_id;
    RETURN user_id;
END;
$$ LANGUAGE plpgsql;

-- Insert Users (and auth.users)
INSERT INTO users (id, email, name, phone, profile_picture, referral_code, referred_by, rank, level, is_admin, deposit_approved)
SELECT
    insert_user_to_auth('admin@gowin.com', 'password123'),
    'admin@gowin.com',
    'Admin User',
    '+1234567890',
    'https://example.com/admin.jpg',
    'ADMIN001',
    NULL,
    'Legend Gold',
    4,
    true,
    true
WHERE NOT EXISTS (SELECT 1 FROM users WHERE email = 'admin@gowin.com');

INSERT INTO users (id, email, name, phone, profile_picture, referral_code, referred_by, rank, level, is_admin, deposit_approved)
SELECT
    insert_user_to_auth('legend.gold@gowin.com', 'password123'),
    'legend.gold@gowin.com',
    'Legend Gold User',
    '+1122334455',
    'https://example.com/legend.jpg',
    'LEGEND01',
    (SELECT id FROM users WHERE email = 'admin@gowin.com'),
    'Legend Gold',
    4,
    false,
    true
WHERE NOT EXISTS (SELECT 1 FROM users WHERE email = 'legend.gold@gowin.com');

INSERT INTO users (id, email, name, phone, profile_picture, referral_code, referred_by, rank, level, is_admin, deposit_approved)
SELECT
    insert_user_to_auth('silver.user@gowin.com', 'password123'),
    'silver.user@gowin.com',
    'Silver Member',
    '+1987654321',
    'https://example.com/silver.jpg',
    'SILVER01',
    (SELECT id FROM users WHERE email = 'legend.gold@gowin.com'),
    'Silver',
    3,
    false,
    true
WHERE NOT EXISTS (SELECT 1 FROM users WHERE email = 'silver.user@gowin.com');

INSERT INTO users (id, email, name, phone, profile_picture, referral_code, referred_by, rank, level, is_admin, deposit_approved)
SELECT
    insert_user_to_auth('bronze.user@gowin.com', 'password123'),
    'bronze.user@gowin.com',
    'Bronze Member',
    '+1555123456',
    'https://example.com/bronze.jpg',
    'BRONZE01',
    (SELECT id FROM users WHERE email = 'silver.user@gowin.com'),
    'Bronze',
    2,
    false,
    true
WHERE NOT EXISTS (SELECT 1 FROM users WHERE email = 'bronze.user@gowin.com');

INSERT INTO users (id, email, name, phone, profile_picture, referral_code, referred_by, rank, level, is_admin, deposit_approved)
SELECT
    insert_user_to_auth('starter.user@gowin.com', 'password123'),
    'starter.user@gowin.com',
    'Starter Member',
    '+1444987654',
    'https://example.com/starter.jpg',
    'STARTER01',
    (SELECT id FROM users WHERE email = 'bronze.user@gowin.com'),
    'Starter',
    1,
    false,
    false
WHERE NOT EXISTS (SELECT 1 FROM users WHERE email = 'starter.user@gowin.com');

INSERT INTO users (id, email, name, phone, profile_picture, referral_code, referred_by, rank, level, is_admin, deposit_approved)
SELECT
    insert_user_to_auth('new.user@gowin.com', 'password123'),
    'new.user@gowin.com',
    'New Member',
    '+1777888999',
    'https://example.com/newuser.jpg',
    'NEWUSER01',
    (SELECT id FROM users WHERE email = 'starter.user@gowin.com'),
    'Starter',
    1,
    false,
    false
WHERE NOT EXISTS (SELECT 1 FROM users WHERE email = 'new.user@gowin.com');

-- Insert Boards
INSERT INTO boards (id, legend_gold_id, level, is_complete)
SELECT
    gen_random_uuid(),
    (SELECT id FROM users WHERE email = 'legend.gold@gowin.com'),
    1,
    false
WHERE NOT EXISTS (SELECT 1 FROM boards WHERE legend_gold_id = (SELECT id FROM users WHERE email = 'legend.gold@gowin.com') AND level = 1);

INSERT INTO boards (id, legend_gold_id, level, is_complete, completed_at)
SELECT
    gen_random_uuid(),
    (SELECT id FROM users WHERE email = 'admin@gowin.com'),
    1,
    true,
    NOW() - INTERVAL '1 month'
WHERE NOT EXISTS (SELECT 1 FROM boards WHERE legend_gold_id = (SELECT id FROM users WHERE email = 'admin@gowin.com') AND level = 1);

-- Insert Board Members
INSERT INTO board_members (board_id, user_id, position, tier)
SELECT
    (SELECT id FROM boards WHERE legend_gold_id = (SELECT id FROM users WHERE email = 'legend.gold@gowin.com') AND level = 1),
    (SELECT id FROM users WHERE email = 'legend.gold@gowin.com'),
    1,
    'Starter'
WHERE NOT EXISTS (SELECT 1 FROM board_members WHERE board_id = (SELECT id FROM boards WHERE legend_gold_id = (SELECT id FROM users WHERE email = 'legend.gold@gowin.com') AND level = 1) AND user_id = (SELECT id FROM users WHERE email = 'legend.gold@gowin.com'));

INSERT INTO board_members (board_id, user_id, position, tier)
SELECT
    (SELECT id FROM boards WHERE legend_gold_id = (SELECT id FROM users WHERE email = 'legend.gold@gowin.com') AND level = 1),
    (SELECT id FROM users WHERE email = 'silver.user@gowin.com'),
    2,
    'Starter'
WHERE NOT EXISTS (SELECT 1 FROM board_members WHERE board_id = (SELECT id FROM boards WHERE legend_gold_id = (SELECT id FROM users WHERE email = 'legend.gold@gowin.com') AND level = 1) AND user_id = (SELECT id FROM users WHERE email = 'silver.user@gowin.com'));

INSERT INTO board_members (board_id, user_id, position, tier)
SELECT
    (SELECT id FROM boards WHERE legend_gold_id = (SELECT id FROM users WHERE email = 'legend.gold@gowin.com') AND level = 1),
    (SELECT id FROM users WHERE email = 'bronze.user@gowin.com'),
    3,
    'Starter'
WHERE NOT EXISTS (SELECT 1 FROM board_members WHERE board_id = (SELECT id FROM boards WHERE legend_gold_id = (SELECT id FROM users WHERE email = 'legend.gold@gowin.com') AND level = 1) AND user_id = (SELECT id FROM users WHERE email = 'bronze.user@gowin.com'));

INSERT INTO board_members (board_id, user_id, position, tier)
SELECT
    (SELECT id FROM boards WHERE legend_gold_id = (SELECT id FROM users WHERE email = 'legend.gold@gowin.com') AND level = 1),
    (SELECT id FROM users WHERE email = 'starter.user@gowin.com'),
    4,
    'Starter'
WHERE NOT EXISTS (SELECT 1 FROM board_members WHERE board_id = (SELECT id FROM boards WHERE legend_gold_id = (SELECT id FROM users WHERE email = 'legend.gold@gowin.com') AND level = 1) AND user_id = (SELECT id FROM users WHERE email = 'starter.user@gowin.com'));

-- Insert Board Join Requests
INSERT INTO board_join_requests (user_id, board_id, amount, payment_method, account_id_number, account_name, status)
SELECT
    (SELECT id FROM users WHERE email = 'new.user@gowin.com'),
    (SELECT id FROM boards WHERE legend_gold_id = (SELECT id FROM users WHERE email = 'legend.gold@gowin.com') AND level = 1),
    100.00,
    'Bank Transfer',
    '1234567890',
    'New User Account',
    'pending'
WHERE NOT EXISTS (SELECT 1 FROM board_join_requests WHERE user_id = (SELECT id FROM users WHERE email = 'new.user@gowin.com') AND board_id = (SELECT id FROM boards WHERE legend_gold_id = (SELECT id FROM users WHERE email = 'legend.gold@gowin.com') AND level = 1));

INSERT INTO board_join_requests (user_id, board_id, amount, payment_method, account_id_number, account_name, status, approved_at, approved_by)
SELECT
    (SELECT id FROM users WHERE email = 'starter.user@gowin.com'),
    (SELECT id FROM boards WHERE legend_gold_id = (SELECT id FROM users WHERE email = 'admin@gowin.com') AND level = 1),
    100.00,
    'Mobile Money',
    '0712345678',
    'Starter User Mpesa',
    'approved',
    NOW() - INTERVAL '2 days',
    (SELECT id FROM users WHERE email = 'admin@gowin.com')
WHERE NOT EXISTS (SELECT 1 FROM board_join_requests WHERE user_id = (SELECT id FROM users WHERE email = 'starter.user@gowin.com') AND board_id = (SELECT id FROM boards WHERE legend_gold_id = (SELECT id FROM users WHERE email = 'admin@gowin.com') AND level = 1));

-- Insert Wallet Balances
INSERT INTO wallet_balances (user_id, main_balance, earning_balance, points)
SELECT
    (SELECT id FROM users WHERE email = 'admin@gowin.com'),
    10000.00,
    5000.00,
    1000
WHERE NOT EXISTS (SELECT 1 FROM wallet_balances WHERE user_id = (SELECT id FROM users WHERE email = 'admin@gowin.com'));

INSERT INTO wallet_balances (user_id, main_balance, earning_balance, points)
SELECT
    (SELECT id FROM users WHERE email = 'legend.gold@gowin.com'),
    5000.00,
    2500.00,
    500
WHERE NOT EXISTS (SELECT 1 FROM wallet_balances WHERE user_id = (SELECT id FROM users WHERE email = 'legend.gold@gowin.com'));

INSERT INTO wallet_balances (user_id, main_balance, earning_balance, points)
SELECT
    (SELECT id FROM users WHERE email = 'silver.user@gowin.com'),
    1500.00,
    750.00,
    150
WHERE NOT EXISTS (SELECT 1 FROM wallet_balances WHERE user_id = (SELECT id FROM users WHERE email = 'silver.user@gowin.com'));

INSERT INTO wallet_balances (user_id, main_balance, earning_balance, points)
SELECT
    (SELECT id FROM users WHERE email = 'bronze.user@gowin.com'),
    500.00,
    250.00,
    50
WHERE NOT EXISTS (SELECT 1 FROM wallet_balances WHERE user_id = (SELECT id FROM users WHERE email = 'bronze.user@gowin.com'));

INSERT INTO wallet_balances (user_id, main_balance, earning_balance, points)
SELECT
    (SELECT id FROM users WHERE email = 'starter.user@gowin.com'),
    100.00,
    0.00,
    10
WHERE NOT EXISTS (SELECT 1 FROM wallet_balances WHERE user_id = (SELECT id FROM users WHERE email = 'starter.user@gowin.com'));

INSERT INTO wallet_balances (user_id, main_balance, earning_balance, points)
SELECT
    (SELECT id FROM users WHERE email = 'new.user@gowin.com'),
    0.00,
    0.00,
    0
WHERE NOT EXISTS (SELECT 1 FROM wallet_balances WHERE user_id = (SELECT id FROM users WHERE email = 'new.user@gowin.com'));

-- Insert Transactions
INSERT INTO transactions (user_id, type, amount, status, description, processed_at)
SELECT
    (SELECT id FROM users WHERE email = 'admin@gowin.com'),
    'deposit',
    10000.00,
    'completed',
    'Initial deposit',
    NOW() - INTERVAL '2 months'
WHERE NOT EXISTS (SELECT 1 FROM transactions WHERE user_id = (SELECT id FROM users WHERE email = 'admin@gowin.com') AND type = 'deposit' AND amount = 10000.00);

INSERT INTO transactions (user_id, type, amount, status, from_user_id, to_user_id, description, processed_at)
SELECT
    (SELECT id FROM users WHERE email = 'legend.gold@gowin.com'),
    'transfer_in',
    500.00,
    'completed',
    (SELECT id FROM users WHERE email = 'admin@gowin.com'),
    (SELECT id FROM users WHERE email = 'legend.gold@gowin.com'),
    'Transfer from admin',
    NOW() - INTERVAL '1 month'
WHERE NOT EXISTS (SELECT 1 FROM transactions WHERE user_id = (SELECT id FROM users WHERE email = 'legend.gold@gowin.com') AND type = 'transfer_in' AND amount = 500.00);

INSERT INTO transactions (user_id, type, amount, status, description, processed_at)
SELECT
    (SELECT id FROM users WHERE email = 'silver.user@gowin.com'),
    'deposit',
    100.00,
    'completed',
    'Board entry deposit',
    NOW() - INTERVAL '2 weeks'
WHERE NOT EXISTS (SELECT 1 FROM transactions WHERE user_id = (SELECT id FROM users WHERE email = 'silver.user@gowin.com') AND type = 'deposit' AND amount = 100.00);

INSERT INTO transactions (user_id, type, amount, status, description)
SELECT
    (SELECT id FROM users WHERE email = 'starter.user@gowin.com'),
    'withdrawal',
    50.00,
    'pending',
    'Pending withdrawal request'
WHERE NOT EXISTS (SELECT 1 FROM transactions WHERE user_id = (SELECT id FROM users WHERE email = 'starter.user@gowin.com') AND type = 'withdrawal' AND amount = 50.00);

-- Insert Withdrawal Requests
INSERT INTO withdrawal_requests (user_id, amount, payment_method, account_id_number, account_name, status)
SELECT
    (SELECT id FROM users WHERE email = 'starter.user@gowin.com'),
    50.00,
    'Mobile Money',
    '0712345678',
    'Starter User Mpesa',
    'pending'
WHERE NOT EXISTS (SELECT 1 FROM withdrawal_requests WHERE user_id = (SELECT id FROM users WHERE email = 'starter.user@gowin.com') AND amount = 50.00);

INSERT INTO withdrawal_requests (user_id, amount, payment_method, account_id_number, account_name, status, approved_at, approved_by)
SELECT
    (SELECT id FROM users WHERE email = 'bronze.user@gowin.com'),
    100.00,
    'Bank Transfer',
    '9876543210',
    'Bronze User Bank',
    'approved',
    NOW() - INTERVAL '1 week',
    (SELECT id FROM users WHERE email = 'admin@gowin.com')
WHERE NOT EXISTS (SELECT 1 FROM withdrawal_requests WHERE user_id = (SELECT id FROM users WHERE email = 'bronze.user@gowin.com') AND amount = 100.00);

-- Insert Referral Earnings
INSERT INTO referral